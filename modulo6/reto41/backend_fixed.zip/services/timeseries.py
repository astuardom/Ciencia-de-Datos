import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
from scipy import stats
from scipy.signal import find_peaks
import re

from core.config import settings
from core.models import TimeSeriesInfo, FrequencyType

logger = logging.getLogger(__name__)


class TimeSeriesService:
    """Servicio de análisis de series de tiempo"""
    
    def __init__(self):
        self.max_points = settings.MAX_TIME_SERIES_POINTS
        self.frequency_patterns = {
            'D': r'\d{4}-\d{2}-\d{2}',  # YYYY-MM-DD
            'W': r'\d{4}-W\d{2}',       # YYYY-WNN
            'M': r'\d{4}-\d{2}',        # YYYY-MM
            'Q': r'\d{4}-Q\d',          # YYYY-QN
            'Y': r'\d{4}'               # YYYY
        }
    
    def analyze_time_series(self, df: pd.DataFrame) -> Optional[TimeSeriesInfo]:
        """
        Analiza si el dataset contiene series de tiempo y detecta su frecuencia
        
        Args:
            df: DataFrame con los datos
            
        Returns:
            Información de series de tiempo o None si no se detectan
        """
        try:
            # Buscar columnas de fecha/hora
            datetime_columns = self._find_datetime_columns(df)
            
            if not datetime_columns:
                return None
            
            logger.info(f"Detected {len(datetime_columns)} datetime columns")
            
            # Analizar cada columna de fecha
            time_series_analysis = []
            for col in datetime_columns:
                analysis = self._analyze_datetime_column(df, col)
                if analysis:
                    time_series_analysis.append(analysis)
            
            if not time_series_analysis:
                return None
            
            # Crear información general de series de tiempo
            return TimeSeriesInfo(
                has_time_series=True,
                datetime_columns=datetime_columns,
                primary_time_column=time_series_analysis[0]['column_name'],
                frequency_detected=time_series_analysis[0]['frequency'],
                time_series_analysis=time_series_analysis,
                resampling_applied=False,
                trend_analysis=self._analyze_trends(df, time_series_analysis[0]),
                seasonality_detected=self._detect_seasonality(df, time_series_analysis[0]),
                anomalies=self._detect_anomalies(df, time_series_analysis[0])
            )
            
        except Exception as e:
            logger.error(f"Error analyzing time series: {e}")
            return None
    
    def _find_datetime_columns(self, df: pd.DataFrame) -> List[str]:
        """Encuentra columnas que contienen fechas"""
        datetime_columns = []
        
        for col in df.columns:
            # Verificar si la columna ya es datetime
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                datetime_columns.append(col)
                continue
            
            # Intentar convertir a datetime
            try:
                # Muestra de datos para detección
                sample = df[col].dropna().head(100)
                if len(sample) == 0:
                    continue
                
                # Intentar parsear como fecha
                pd.to_datetime(sample, errors='coerce')
                datetime_columns.append(col)
                
            except (ValueError, TypeError):
                continue
        
        return datetime_columns
    
    def _analyze_datetime_column(self, df: pd.DataFrame, col: str) -> Optional[Dict[str, Any]]:
        """Analiza una columna específica de fecha/hora"""
        try:
            # Convertir a datetime si no lo es
            if not pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = pd.to_datetime(df[col], errors='coerce')
            
            # Remover valores nulos
            df_clean = df[col].dropna()
            if len(df_clean) < 2:
                return None
            
            # Ordenar por fecha
            df_clean = df_clean.sort_values()
            
            # Detectar frecuencia
            frequency = self._detect_frequency(df_clean)
            
            # Calcular estadísticas básicas
            date_range = df_clean.max() - df_clean.min()
            total_days = date_range.days
            
            # Detectar gaps en la serie
            gaps = self._detect_gaps(df_clean, frequency)
            
            return {
                'column_name': col,
                'frequency': frequency,
                'start_date': df_clean.min(),
                'end_date': df_clean.max(),
                'total_days': total_days,
                'total_records': len(df_clean),
                'gaps_detected': gaps,
                'is_continuous': len(gaps) == 0
            }
            
        except Exception as e:
            logger.error(f"Error analyzing datetime column {col}: {e}")
            return None
    
    def _detect_frequency(self, series: pd.Series) -> FrequencyType:
        """Detecta la frecuencia de la serie temporal"""
        try:
            # Calcular diferencias entre fechas consecutivas
            diffs = series.diff().dropna()
            
            if len(diffs) == 0:
                return FrequencyType.IRREGULAR
            
            # Convertir a días
            diffs_days = diffs.dt.total_seconds() / (24 * 3600)
            
            # Analizar patrones de frecuencia
            median_diff = diffs_days.median()
            std_diff = diffs_days.std()
            
            # Detectar frecuencia basada en la mediana
            if median_diff <= 1.1:  # ~1 día
                return FrequencyType.DAILY
            elif median_diff <= 7.1:  # ~1 semana
                return FrequencyType.WEEKLY
            elif median_diff <= 31.1:  # ~1 mes
                return FrequencyType.MONTHLY
            elif median_diff <= 92.1:  # ~3 meses
                return FrequencyType.QUARTERLY
            elif median_diff <= 366.1:  # ~1 año
                return FrequencyType.YEARLY
            else:
                return FrequencyType.IRREGULAR
                
        except Exception as e:
            logger.error(f"Error detecting frequency: {e}")
            return FrequencyType.IRREGULAR
    
    def _detect_gaps(self, series: pd.Series, frequency: FrequencyType) -> List[Dict[str, Any]]:
        """Detecta gaps en la serie temporal"""
        gaps = []
        
        try:
            # Crear serie completa esperada
            expected_dates = pd.date_range(
                start=series.min(),
                end=series.max(),
                freq=self._get_pandas_freq(frequency)
            )
            
            # Encontrar fechas faltantes
            missing_dates = expected_dates.difference(series)
            
            if len(missing_dates) > 0:
                # Agrupar gaps consecutivos
                gaps = self._group_consecutive_gaps(missing_dates)
        
        except Exception as e:
            logger.error(f"Error detecting gaps: {e}")
        
        return gaps
    
    def _get_pandas_freq(self, frequency: FrequencyType) -> str:
        """Convierte FrequencyType a frecuencia de pandas"""
        freq_map = {
            FrequencyType.DAILY: 'D',
            FrequencyType.WEEKLY: 'W',
            FrequencyType.MONTHLY: 'M',
            FrequencyType.QUARTERLY: 'Q',
            FrequencyType.YEARLY: 'Y'
        }
        return freq_map.get(frequency, 'D')
    
    def _group_consecutive_gaps(self, missing_dates: pd.DatetimeIndex) -> List[Dict[str, Any]]:
        """Agrupa fechas faltantes consecutivas"""
        if len(missing_dates) == 0:
            return []
        
        gaps = []
        start_date = missing_dates[0]
        prev_date = start_date
        
        for date in missing_dates[1:]:
            if (date - prev_date).days > 1:
                # Gap terminó, agregar al grupo
                gaps.append({
                    'start_date': start_date,
                    'end_date': prev_date,
                    'duration_days': (prev_date - start_date).days + 1
                })
                start_date = date
            prev_date = date
        
        # Agregar último gap
        gaps.append({
            'start_date': start_date,
            'end_date': prev_date,
            'duration_days': (prev_date - start_date).days + 1
        })
        
        return gaps
    
    def _analyze_trends(self, df: pd.DataFrame, time_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Analiza tendencias en la serie temporal"""
        try:
            col = time_analysis['column_name']
            df_clean = df[col].dropna()
            
            if len(df_clean) < 3:
                return {'trend_detected': False}
            
            # Crear índice numérico para análisis de tendencia
            x = np.arange(len(df_clean))
            y = df_clean.astype(np.int64) // 10**9  # Convertir a timestamp Unix
            
            # Regresión lineal simple
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            # Determinar dirección de la tendencia
            if abs(slope) < 1e-10:
                trend_direction = 'stable'
            elif slope > 0:
                trend_direction = 'increasing'
            else:
                trend_direction = 'decreasing'
            
            return {
                'trend_detected': True,
                'trend_direction': trend_direction,
                'slope': slope,
                'r_squared': r_value**2,
                'p_value': p_value,
                'strength': 'strong' if abs(r_value) > 0.7 else 'moderate' if abs(r_value) > 0.5 else 'weak'
            }
            
        except Exception as e:
            logger.error(f"Error analyzing trends: {e}")
            return {'trend_detected': False}
    
    def _detect_seasonality(self, df: pd.DataFrame, time_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Detecta patrones estacionales"""
        try:
            col = time_analysis['column_name']
            df_clean = df[col].dropna()
            
            if len(df_clean) < 30:  # Necesitamos suficientes datos
                return {'seasonality_detected': False}
            
            # Extraer componentes temporales
            df_clean = df_clean.sort_values()
            
            # Detectar patrones por día de la semana
            weekday_counts = df_clean.dt.dayofweek.value_counts().sort_index()
            weekday_variance = weekday_counts.var()
            
            # Detectar patrones por mes
            month_counts = df_clean.dt.month.value_counts().sort_index()
            month_variance = month_counts.var()
            
            # Detectar patrones por hora (si hay datos de hora)
            hour_variance = 0
            if df_clean.dt.hour.nunique() > 1:
                hour_counts = df_clean.dt.hour.value_counts().sort_index()
                hour_variance = hour_counts.var()
            
            # Determinar si hay estacionalidad
            total_variance = weekday_variance + month_variance + hour_variance
            seasonality_detected = total_variance > 0.1  # Umbral ajustable
            
            return {
                'seasonality_detected': seasonality_detected,
                'weekly_pattern': weekday_variance > 0.05,
                'monthly_pattern': month_variance > 0.05,
                'hourly_pattern': hour_variance > 0.05,
                'strength': 'strong' if total_variance > 0.3 else 'moderate' if total_variance > 0.1 else 'weak'
            }
            
        except Exception as e:
            logger.error(f"Error detecting seasonality: {e}")
            return {'seasonality_detected': False}
    
    def _detect_anomalies(self, df: pd.DataFrame, time_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Detecta anomalías en la serie temporal"""
        try:
            col = time_analysis['column_name']
            df_clean = df[col].dropna()
            
            if len(df_clean) < 10:
                return {'anomalies_detected': False}
            
            # Ordenar por fecha
            df_clean = df_clean.sort_values()
            
            # Calcular diferencias entre fechas consecutivas
            diffs = df_clean.diff().dropna()
            
            if len(diffs) == 0:
                return {'anomalies_detected': False}
            
            # Convertir a días
            diffs_days = diffs.dt.total_seconds() / (24 * 3600)
            
            # Detectar outliers usando IQR
            Q1 = diffs_days.quantile(0.25)
            Q3 = diffs_days.quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            anomalies = diffs_days[(diffs_days < lower_bound) | (diffs_days > upper_bound)]
            
            return {
                'anomalies_detected': len(anomalies) > 0,
                'anomaly_count': len(anomalies),
                'anomaly_percentage': (len(anomalies) / len(diffs_days)) * 100,
                'anomaly_dates': df_clean[diffs_days.isin(anomalies)].tolist() if len(anomalies) > 0 else []
            }
            
        except Exception as e:
            logger.error(f"Error detecting anomalies: {e}")
            return {'anomalies_detected': False}
    
    def resample_time_series(self, df: pd.DataFrame, time_column: str, 
                            target_frequency: FrequencyType) -> pd.DataFrame:
        """
        Resamplea la serie temporal a una frecuencia específica
        
        Args:
            df: DataFrame con los datos
            time_column: Columna de fecha/hora
            target_frequency: Frecuencia objetivo
            
        Returns:
            DataFrame resampleado
        """
        try:
            # Asegurar que la columna sea datetime
            if not pd.api.types.is_datetime64_any_dtype(df[time_column]):
                df[time_column] = pd.to_datetime(df[time_column], errors='coerce')
            
            # Ordenar por fecha
            df_sorted = df.sort_values(time_column)
            
            # Establecer índice temporal
            df_indexed = df_sorted.set_index(time_column)
            
            # Resamplear
            freq_str = self._get_pandas_freq(target_frequency)
            df_resampled = df_indexed.resample(freq_str).agg({
                col: 'mean' if pd.api.types.is_numeric_dtype(df[col]) else 'first'
                for col in df.columns if col != time_column
            })
            
            # Resetear índice
            df_resampled = df_resampled.reset_index()
            
            # Limitar puntos si es necesario
            if len(df_resampled) > self.max_points:
                df_resampled = df_resampled.sample(n=self.max_points).sort_values(time_column)
            
            return df_resampled
            
        except Exception as e:
            logger.error(f"Error resampling time series: {e}")
            return df


# Instancia global del servicio
time_series_service = TimeSeriesService()
