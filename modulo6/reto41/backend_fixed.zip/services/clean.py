import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Union
import logging
from pathlib import Path
import tempfile
import os
from datetime import datetime
import re

from core.config import settings
from core.models import DataType, ColumnProfile

logger = logging.getLogger(__name__)


class CleanDataService:
    """Servicio de limpieza y exportación de datos"""
    
    def __init__(self):
        self.max_export_rows = 1000000  # Límite de filas para exportación
        self.cleanup_strategies = {
            'numeric': self._clean_numeric_column,
            'categorical': self._clean_categorical_column,
            'datetime': self._clean_datetime_column,
            'text': self._clean_text_column,
            'boolean': self._clean_boolean_column
        }
    
    def export_clean_data(self, df: pd.DataFrame, dataset_id: str, 
                         format_type: str = 'csv', profile: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        """
        Exporta datos limpios en el formato especificado
        
        Args:
            df: DataFrame con los datos
            dataset_id: ID del dataset
            format_type: Formato de exportación ('csv' o 'parquet')
            profile: Perfil del dataset para aplicar limpieza inteligente
            
        Returns:
            Diccionario con información del archivo exportado
        """
        try:
            logger.info(f"Exporting clean data for dataset {dataset_id} in {format_type} format")
            
            # Aplicar limpieza inteligente si hay perfil
            if profile:
                df_clean = self._apply_intelligent_cleaning(df, profile)
            else:
                df_clean = self._apply_basic_cleaning(df)
            
            # Limitar filas si es necesario
            if len(df_clean) > self.max_export_rows:
                df_clean = df_clean.head(self.max_export_rows)
                logger.warning(f"Data truncated to {self.max_export_rows} rows for export")
            
            # Exportar según formato
            if format_type.lower() == 'parquet':
                return self._export_parquet(df_clean, dataset_id)
            else:
                return self._export_csv(df_clean, dataset_id)
                
        except Exception as e:
            logger.error(f"Error exporting clean data: {e}")
            raise
    
    def _apply_intelligent_cleaning(self, df: pd.DataFrame, profile: Dict[str, Any]) -> pd.DataFrame:
        """Aplica limpieza inteligente basada en el perfil del dataset"""
        try:
            df_clean = df.copy()
            columns = profile.get('columns', [])
            
            for col_profile in columns:
                col_name = col_profile.get('name')
                if col_name not in df_clean.columns:
                    continue
                
                data_type = col_profile.get('data_type')
                if data_type in self.cleanup_strategies:
                    df_clean[col_name] = self.cleanup_strategies[data_type](
                        df_clean[col_name], col_profile
                    )
            
            # Aplicar limpieza adicional basada en insights
            df_clean = self._apply_insight_based_cleaning(df_clean, profile)
            
            return df_clean
            
        except Exception as e:
            logger.error(f"Error applying intelligent cleaning: {e}")
            return df
    
    def _apply_basic_cleaning(self, df: pd.DataFrame) -> pd.DataFrame:
        """Aplica limpieza básica estándar"""
        try:
            df_clean = df.copy()
            
            # Limpiar nombres de columnas
            df_clean.columns = [self._clean_column_name(col) for col in df_clean.columns]
            
            # Remover filas completamente vacías
            df_clean = df_clean.dropna(how='all')
            
            # Remover columnas completamente vacías
            df_clean = df_clean.dropna(axis=1, how='all')
            
            # Limpiar espacios en blanco para columnas de texto
            text_columns = df_clean.select_dtypes(include=['object']).columns
            for col in text_columns:
                if df_clean[col].dtype == 'object':
                    df_clean[col] = df_clean[col].astype(str).str.strip()
            
            return df_clean
            
        except Exception as e:
            logger.error(f"Error applying basic cleaning: {e}")
            return df
    
    def _clean_column_name(self, column_name: str) -> str:
        """Limpia el nombre de una columna"""
        try:
            # Convertir a string si no lo es
            col_str = str(column_name)
            
            # Remover caracteres especiales y espacios
            col_clean = re.sub(r'[^\w\s-]', '', col_str)
            
            # Reemplazar espacios y guiones con underscore
            col_clean = re.sub(r'[\s-]+', '_', col_clean)
            
            # Convertir a snake_case
            col_clean = col_clean.lower().strip('_')
            
            # Asegurar que no esté vacío
            if not col_clean:
                col_clean = 'column'
            
            return col_clean
            
        except Exception as e:
            logger.error(f"Error cleaning column name {column_name}: {e}")
            return str(column_name)
    
    def _clean_numeric_column(self, series: pd.Series, profile: Dict[str, Any]) -> pd.Series:
        """Limpia una columna numérica"""
        try:
            # Convertir a numérico, coercing errors
            series_clean = pd.to_numeric(series, errors='coerce')
            
            # Aplicar sugerencias del perfil
            suggestions = profile.get('suggestions', [])
            
            # Detectar y manejar outliers si se sugiere
            if 'handle_outliers' in suggestions:
                series_clean = self._handle_outliers(series_clean)
            
            # Aplicar transformaciones si se sugiere
            if 'log_transform' in suggestions:
                # Aplicar log transform solo a valores positivos
                positive_mask = series_clean > 0
                if positive_mask.any():
                    series_clean[positive_mask] = np.log(series_clean[positive_mask])
            
            return series_clean
            
        except Exception as e:
            logger.error(f"Error cleaning numeric column: {e}")
            return series
    
    def _clean_categorical_column(self, series: pd.Series, profile: Dict[str, Any]) -> pd.Series:
        """Limpia una columna categórica"""
        try:
            # Convertir a string
            series_clean = series.astype(str)
            
            # Aplicar normalización de texto
            series_clean = series_clean.str.strip()
            series_clean = series_clean.str.lower()
            
            # Normalizar valores comunes
            series_clean = self._normalize_common_values(series_clean)
            
            # Aplicar sugerencias del perfil
            suggestions = profile.get('suggestions', [])
            
            # Codificar si se sugiere
            if 'encode' in suggestions:
                # Usar LabelEncoder para valores únicos
                unique_values = series_clean.nunique()
                if unique_values < 100:  # Solo si hay pocas categorías
                    from sklearn.preprocessing import LabelEncoder
                    le = LabelEncoder()
                    series_clean = le.fit_transform(series_clean)
            
            return series_clean
            
        except Exception as e:
            logger.error(f"Error cleaning categorical column: {e}")
            return series
    
    def _clean_datetime_column(self, series: pd.Series, profile: Dict[str, Any]) -> pd.Series:
        """Limpia una columna de fecha/hora"""
        try:
            # Intentar convertir a datetime
            series_clean = pd.to_datetime(series, errors='coerce')
            
            # Aplicar sugerencias del perfil
            suggestions = profile.get('suggestions', [])
            
            # Normalizar zona horaria si se sugiere
            if 'normalize_timezone' in suggestions:
                # Asumir UTC si no hay zona horaria
                series_clean = series_clean.dt.tz_localize('UTC', ambiguous='infer')
            
            # Extraer componentes si se sugiere
            if 'extract_components' in suggestions:
                # Crear columnas adicionales para año, mes, día, etc.
                pass  # Implementar si es necesario
            
            return series_clean
            
        except Exception as e:
            logger.error(f"Error cleaning datetime column: {e}")
            return series
    
    def _clean_text_column(self, series: pd.Series, profile: Dict[str, Any]) -> pd.Series:
        """Limpia una columna de texto"""
        try:
            # Convertir a string
            series_clean = series.astype(str)
            
            # Limpiar espacios
            series_clean = series_clean.str.strip()
            
            # Normalizar espacios múltiples
            series_clean = series_clean.str.replace(r'\s+', ' ', regex=True)
            
            # Aplicar sugerencias del perfil
            suggestions = profile.get('suggestions', [])
            
            # Remover caracteres especiales si se sugiere
            if 'remove_special_chars' in suggestions:
                series_clean = series_clean.str.replace(r'[^\w\s]', '', regex=True)
            
            # Convertir a minúsculas si se sugiere
            if 'lowercase' in suggestions:
                series_clean = series_clean.str.lower()
            
            return series_clean
            
        except Exception as e:
            logger.error(f"Error cleaning text column: {e}")
            return series
    
    def _clean_boolean_column(self, series: pd.Series, profile: Dict[str, Any]) -> pd.Series:
        """Limpia una columna booleana"""
        try:
            # Normalizar valores booleanos
            boolean_map = {
                'true': True, 'false': False,
                '1': True, '0': False,
                'yes': True, 'no': False,
                'sí': True, 'no': False,
                'si': True, 'no': False,
                'on': True, 'off': False,
                'enabled': True, 'disabled': False,
                'active': True, 'inactive': False
            }
            
            # Convertir a string y normalizar
            series_str = series.astype(str).str.lower().str.strip()
            
            # Aplicar mapeo
            series_clean = series_str.map(boolean_map)
            
            # Convertir a boolean
            series_clean = series_clean.astype('boolean')
            
            return series_clean
            
        except Exception as e:
            logger.error(f"Error cleaning boolean column: {e}")
            return series
    
    def _normalize_common_values(self, series: pd.Series) -> pd.Series:
        """Normaliza valores comunes en columnas categóricas"""
        try:
            # Mapeo de valores comunes
            common_mappings = {
                'n/a': 'NA',
                'none': 'NA',
                'null': 'NA',
                'undefined': 'NA',
                'unknown': 'NA',
                'missing': 'NA',
                'empty': 'NA',
                'sin datos': 'NA',
                'no disponible': 'NA',
                'no aplica': 'NA'
            }
            
            # Aplicar mapeo
            series_normalized = series.replace(common_mappings)
            
            return series_normalized
            
        except Exception as e:
            logger.error(f"Error normalizing common values: {e}")
            return series
    
    def _handle_outliers(self, series: pd.Series) -> pd.Series:
        """Maneja outliers en columnas numéricas"""
        try:
            # Calcular límites usando IQR
            Q1 = series.quantile(0.25)
            Q3 = series.quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            # Crear máscara para outliers
            outlier_mask = (series < lower_bound) | (series > upper_bound)
            
            # Reemplazar outliers con límites
            series_clean = series.copy()
            series_clean[series < lower_bound] = lower_bound
            series_clean[series > upper_bound] = upper_bound
            
            return series_clean
            
        except Exception as e:
            logger.error(f"Error handling outliers: {e}")
            return series
    
    def _apply_insight_based_cleaning(self, df: pd.DataFrame, profile: Dict[str, Any]) -> pd.DataFrame:
        """Aplica limpieza basada en insights del perfil"""
        try:
            df_clean = df.copy()
            
            # Aplicar limpieza basada en correlaciones
            correlations = profile.get('correlations', {})
            if correlations:
                # Identificar variables altamente correlacionadas
                high_corr_pairs = []
                for var1, corr_data in correlations.items():
                    if isinstance(corr_data, dict):
                        for var2, corr_value in corr_data.items():
                            if var1 != var2 and abs(corr_value) > 0.95:
                                high_corr_pairs.append((var1, var2))
                
                # Remover una de las variables altamente correlacionadas
                for var1, var2 in high_corr_pairs[:3]:  # Máximo 3 pares
                    if var1 in df_clean.columns and var2 in df_clean.columns:
                        df_clean = df_clean.drop(columns=[var2])
                        logger.info(f"Removed highly correlated column: {var2}")
            
            # Aplicar limpieza basada en valores faltantes
            missing_analysis = profile.get('missing_patterns', {})
            if missing_analysis:
                # Remover columnas con demasiados valores faltantes
                high_missing_cols = [
                    col for col in df_clean.columns
                    if df_clean[col].isnull().sum() / len(df_clean) > 0.8
                ]
                if high_missing_cols:
                    df_clean = df_clean.drop(columns=high_missing_cols)
                    logger.info(f"Removed columns with >80% missing values: {high_missing_cols}")
            
            return df_clean
            
        except Exception as e:
            logger.error(f"Error applying insight-based cleaning: {e}")
            return df
    
    def _export_csv(self, df: pd.DataFrame, dataset_id: str) -> Dict[str, str]:
        """Exporta datos a CSV"""
        try:
            filename = f"{dataset_id}_clean.csv"
            file_path = settings.artifacts_dir / filename
            
            # Exportar a CSV
            df.to_csv(file_path, index=False, encoding='utf-8')
            
            file_size = file_path.stat().st_size
            file_size_mb = file_size / (1024 * 1024)
            
            logger.info(f"CSV exported: {file_path} ({file_size_mb:.2f} MB)")
            
            return {
                'format': 'csv',
                'file_path': str(file_path),
                'file_url': f"/artifacts/{filename}",
                'file_size_mb': file_size_mb,
                'rows': len(df),
                'columns': len(df.columns),
                'exported_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error exporting CSV: {e}")
            raise
    
    def _export_parquet(self, df: pd.DataFrame, dataset_id: str) -> Dict[str, str]:
        """Exporta datos a Parquet"""
        try:
            filename = f"{dataset_id}_clean.parquet"
            file_path = settings.artifacts_dir / filename
            
            # Exportar a Parquet
            df.to_parquet(file_path, index=False, compression='snappy')
            
            file_size = file_path.stat().st_size
            file_size_mb = file_size / (1024 * 1024)
            
            logger.info(f"Parquet exported: {file_path} ({file_size_mb:.2f} MB)")
            
            return {
                'format': 'parquet',
                'file_path': str(file_path),
                'file_url': f"/artifacts/{filename}",
                'file_size_mb': file_size_mb,
                'rows': len(df),
                'columns': len(df.columns),
                'exported_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error exporting Parquet: {e}")
            raise
    
    def get_cleaning_summary(self, df_original: pd.DataFrame, df_clean: pd.DataFrame) -> Dict[str, Any]:
        """Genera un resumen de la limpieza aplicada"""
        try:
            summary = {
                'original_rows': len(df_original),
                'original_columns': len(df_original.columns),
                'clean_rows': len(df_clean),
                'clean_columns': len(df_clean.columns),
                'rows_removed': len(df_original) - len(df_clean),
                'columns_removed': len(df_original.columns) - len(df_clean.columns),
                'cleaning_applied': []
            }
            
            # Detectar tipos de limpieza aplicados
            if len(df_clean) < len(df_original):
                summary['cleaning_applied'].append('removed_empty_rows')
            
            if len(df_clean.columns) < len(df_original.columns):
                summary['cleaning_applied'].append('removed_empty_columns')
            
            # Detectar normalización de nombres
            original_names = set(df_original.columns)
            clean_names = set(df_clean.columns)
            if original_names != clean_names:
                summary['cleaning_applied'].append('normalized_column_names')
            
            # Detectar limpieza de tipos de datos
            type_changes = 0
            for col in df_clean.columns:
                if col in df_original.columns:
                    if df_original[col].dtype != df_clean[col].dtype:
                        type_changes += 1
            
            if type_changes > 0:
                summary['cleaning_applied'].append('optimized_data_types')
                summary['type_changes'] = type_changes
            
            return summary
            
        except Exception as e:
            logger.error(f"Error generating cleaning summary: {e}")
            return {}


# Instancia global del servicio
clean_data_service = CleanDataService()
