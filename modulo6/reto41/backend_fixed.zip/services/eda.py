import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import logging
from scipy import stats
from sklearn.preprocessing import LabelEncoder
import re
from pathlib import Path

from core.config import settings
from core.models import (
    DatasetSummary, DatasetProfile, ColumnProfile, DataType,
    generate_dataset_id
)
from core.cache import cache_manager

logger = logging.getLogger(__name__)


class EDAService:
    """Servicio de Análisis Exploratorio de Datos (EDA)"""
    
    def __init__(self):
        self.max_rows_for_full_analysis = settings.MAX_ROWS_FOR_FULL_ANALYSIS
        self.sample_size_for_large_datasets = settings.SAMPLE_SIZE_FOR_LARGE_DATASETS
        self.outlier_threshold = settings.OUTLIER_THRESHOLD
        self.correlation_threshold = settings.CORRELATION_THRESHOLD
    
    def analyze_dataset(self, df: pd.DataFrame, dataset_id: str, file_path: Path) -> DatasetProfile:
        """
        Realiza análisis completo del dataset
        
        Args:
            df: DataFrame con los datos
            dataset_id: ID del dataset
            file_path: Ruta al archivo original
            
        Returns:
            Perfil completo del dataset
        """
        try:
            # Verificar caché primero
            cached_profile = cache_manager.get_cached_result(file_path, "profile")
            if cached_profile:
                logger.info(f"Using cached profile for dataset {dataset_id}")
                return cached_profile
            
            logger.info(f"Starting EDA analysis for dataset {dataset_id}")
            
            # Aplicar muestreo si es necesario
            df_analyzed, sampling_info = self._apply_sampling(df)
            
            # Crear resumen del dataset
            summary = self._create_dataset_summary(df, df_analyzed, dataset_id, sampling_info)
            
            # Analizar columnas
            columns = self._analyze_columns(df_analyzed)
            
            # Análisis estadístico
            correlations = self._analyze_correlations(df_analyzed)
            missing_patterns = self._analyze_missing_patterns(df_analyzed)
            outlier_analysis = self._analyze_outliers(df_analyzed)
            
            # Análisis de series de tiempo
            time_series_info = self._analyze_time_series(df_analyzed)
            
            # Crear perfil completo
            profile = DatasetProfile(
                dataset_id=dataset_id,
                summary=summary,
                columns=columns,
                correlations=correlations,
                missing_patterns=missing_patterns,
                outlier_analysis=outlier_analysis,
                time_series_info=time_series_info,
                generated_at=datetime.now()
            )
            
            # Guardar en caché
            cache_manager.cache_result(file_path, "profile", profile)
            
            logger.info(f"EDA analysis completed for dataset {dataset_id}")
            return profile
            
        except Exception as e:
            logger.error(f"Error in EDA analysis: {e}")
            raise
    
    def _apply_sampling(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Aplica muestreo inteligente si el dataset es muy grande
        
        Args:
            df: DataFrame original
            
        Returns:
            Tuple de (DataFrame muestreado, información del muestreo)
        """
        original_rows = len(df)
        sampling_info = {
            'sampling_applied': False,
            'original_row_count': original_rows,
            'sample_size': original_rows,
            'sampling_method': None,
            'sampling_notice': None
        }
        
        if original_rows <= self.max_rows_for_full_analysis:
            return df, sampling_info
        
        # Aplicar muestreo estratificado si hay columnas categóricas
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns
        
        if len(categorical_cols) > 0:
            # Muestreo estratificado
            df_sampled = self._stratified_sampling(df, categorical_cols[0])
            sampling_info.update({
                'sampling_applied': True,
                'sample_size': len(df_sampled),
                'sampling_method': 'stratified',
                'sampling_notice': f"Muestreo estratificado aplicado: {len(df_sampled):,} filas de {original_rows:,} originales"
            })
        else:
            # Muestreo aleatorio simple
            df_sampled = df.sample(n=self.sample_size_for_large_datasets, random_state=42)
            sampling_info.update({
                'sampling_applied': True,
                'sample_size': len(df_sampled),
                'sampling_method': 'random',
                'sampling_notice': f"Muestreo aleatorio aplicado: {len(df_sampled):,} filas de {original_rows:,} originales"
            })
        
        return df_sampled, sampling_info
    
    def _stratified_sampling(self, df: pd.DataFrame, stratify_col: str, sample_size: int = None) -> pd.DataFrame:
        """Realiza muestreo estratificado basado en una columna categórica"""
        if sample_size is None:
            sample_size = self.sample_size_for_large_datasets
        
        # Obtener distribución de la columna de estratificación
        value_counts = df[stratify_col].value_counts()
        
        # Calcular proporción de cada categoría
        total_rows = len(df)
        sample_proportions = {}
        
        for category, count in value_counts.items():
            proportion = count / total_rows
            sample_proportions[category] = int(proportion * sample_size)
        
        # Ajustar para asegurar que la suma sea exactamente sample_size
        total_sampled = sum(sample_proportions.values())
        if total_sampled < sample_size:
            # Agregar filas adicionales a la categoría más grande
            largest_category = max(sample_proportions.items(), key=lambda x: x[1])[0]
            sample_proportions[largest_category] += (sample_size - total_sampled)
        
        # Realizar muestreo estratificado
        sampled_dfs = []
        for category, n_samples in sample_proportions.items():
            if n_samples > 0:
                category_df = df[df[stratify_col] == category]
                if len(category_df) >= n_samples:
                    sampled = category_df.sample(n=n_samples, random_state=42)
                else:
                    sampled = category_df  # Usar todas las filas disponibles
                sampled_dfs.append(sampled)
        
        return pd.concat(sampled_dfs, ignore_index=True)


# Instancia global del servicio EDA
eda_service = EDAService()
