import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
import logging
from pathlib import Path
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.io as pio
from datetime import datetime
import json

from core.config import settings
from core.models import ChartTrace, ChartType, DataType

logger = logging.getLogger(__name__)

# Configurar Plotly para exportación estática
pio.kaleido.scope.default_width = settings.CHART_WIDTH
pio.kaleido.scope.default_height = settings.CHART_HEIGHT


class ChartsService:
    """Servicio de generación de gráficos y visualizaciones"""
    
    def __init__(self):
        self.max_bins = settings.MAX_CHART_BINS
        self.max_time_series_points = settings.MAX_TIME_SERIES_POINTS
        self.chart_height = settings.CHART_HEIGHT
        self.chart_width = settings.CHART_WIDTH
    
    def generate_charts(self, df: pd.DataFrame, profile: Dict[str, Any], 
                       time_series_info: Optional[Dict[str, Any]] = None) -> List[ChartTrace]:
        """
        Genera todos los gráficos relevantes para el dataset
        
        Args:
            df: DataFrame con los datos
            profile: Perfil del dataset
            time_series_info: Información de series de tiempo si existe
            
        Returns:
            Lista de trazas de gráficos
        """
        try:
            charts = []
            
            # Gráficos de distribución para columnas numéricas
            numeric_charts = self._generate_numeric_charts(df, profile)
            charts.extend(numeric_charts)
            
            # Gráficos de categorías para columnas categóricas
            categorical_charts = self._generate_categorical_charts(df, profile)
            charts.extend(categorical_charts)
            
            # Gráficos de correlación
            correlation_charts = self._generate_correlation_charts(df, profile)
            charts.extend(correlation_charts)
            
            # Gráficos de series de tiempo
            if time_series_info:
                time_series_charts = self._generate_time_series_charts(df, time_series_info)
                charts.extend(time_series_charts)
            
            # Gráficos de calidad de datos
            quality_charts = self._generate_data_quality_charts(df, profile)
            charts.extend(quality_charts)
            
            logger.info(f"Generated {len(charts)} charts")
            return charts
            
        except Exception as e:
            logger.error(f"Error generating charts: {e}")
            return []
    
    def _generate_numeric_charts(self, df: pd.DataFrame, profile: Dict[str, Any]) -> List[ChartTrace]:
        """Genera gráficos para columnas numéricas"""
        charts = []
        
        try:
            numeric_columns = [
                col for col in df.columns 
                if pd.api.types.is_numeric_dtype(df[col]) and df[col].notna().sum() > 0
            ]
            
            for col in numeric_columns[:10]:  # Limitar a 10 columnas
                # Histograma
                hist_trace = self._create_histogram(df, col)
                if hist_trace:
                    charts.append(hist_trace)
                
                # Box plot
                box_trace = self._create_boxplot(df, col)
                if box_trace:
                    charts.append(box_trace)
                
                # Q-Q plot para normalidad
                qq_trace = self._create_qq_plot(df, col)
                if qq_trace:
                    charts.append(qq_trace)
        
        except Exception as e:
            logger.error(f"Error generating numeric charts: {e}")
        
        return charts
    
    def _generate_categorical_charts(self, df: pd.DataFrame, profile: Dict[str, Any]) -> List[ChartTrace]:
        """Genera gráficos para columnas categóricas"""
        charts = []
        
        try:
            categorical_columns = [
                col for col in df.columns 
                if not pd.api.types.is_numeric_dtype(df[col]) and df[col].notna().sum() > 0
            ]
            
            for col in categorical_columns[:8]:  # Limitar a 8 columnas
                # Bar chart
                bar_trace = self._create_bar_chart(df, col)
                if bar_trace:
                    charts.append(bar_trace)
                
                # Pie chart (solo si hay pocas categorías)
                if df[col].nunique() <= 10:
                    pie_trace = self._create_pie_chart(df, col)
                    if pie_trace:
                        charts.append(pie_trace)
        
        except Exception as e:
            logger.error(f"Error generating categorical charts: {e}")
        
        return charts
    
    def _generate_correlation_charts(self, df: pd.DataFrame, profile: Dict[str, Any]) -> List[ChartTrace]:
        """Genera gráficos de correlación"""
        charts = []
        
        try:
            numeric_df = df.select_dtypes(include=[np.number])
            
            if len(numeric_df.columns) < 2:
                return charts
            
            # Matriz de correlación
            corr_matrix = numeric_df.corr()
            
            # Heatmap de correlaciones
            heatmap_trace = self._create_correlation_heatmap(corr_matrix)
            if heatmap_trace:
                charts.append(heatmap_trace)
            
            # Scatter plots para correlaciones fuertes
            strong_correlations = self._find_strong_correlations(corr_matrix)
            for col1, col2, corr_value in strong_correlations[:5]:  # Top 5
                scatter_trace = self._create_scatter_plot(df, col1, col2, corr_value)
                if scatter_trace:
                    charts.append(scatter_trace)
        
        except Exception as e:
            logger.error(f"Error generating correlation charts: {e}")
        
        return charts
    
    def _generate_time_series_charts(self, df: pd.DataFrame, time_series_info: Dict[str, Any]) -> List[ChartTrace]:
        """Genera gráficos de series de tiempo"""
        charts = []
        
        try:
            primary_time_col = time_series_info.get('primary_time_column')
            if not primary_time_col:
                return charts
            
            # Asegurar que la columna sea datetime
            if not pd.api.types.is_datetime64_any_dtype(df[primary_time_col]):
                df[primary_time_col] = pd.to_datetime(df[primary_time_col], errors='coerce')
            
            # Ordenar por fecha
            df_sorted = df.sort_values(primary_time_col)
            
            # Línea de tiempo para columnas numéricas
            numeric_cols = df.select_dtypes(include=[np.number]).columns[:3]  # Top 3
            
            for col in numeric_cols:
                line_trace = self._create_time_series_line(df_sorted, primary_time_col, col)
                if line_trace:
                    charts.append(line_trace)
            
            # Gráfico de tendencia
            trend_trace = self._create_trend_chart(df_sorted, primary_time_col, numeric_cols[0] if len(numeric_cols) > 0 else None)
            if trend_trace:
                charts.append(trend_trace)
        
        except Exception as e:
            logger.error(f"Error generating time series charts: {e}")
        
        return charts
    
    def _generate_data_quality_charts(self, df: pd.DataFrame, profile: Dict[str, Any]) -> List[ChartTrace]:
        """Genera gráficos de calidad de datos"""
        charts = []
        
        try:
            # Gráfico de valores faltantes
            missing_trace = self._create_missing_values_chart(df)
            if missing_trace:
                charts.append(missing_trace)
            
            # Gráfico de duplicados
            duplicates_trace = self._create_duplicates_chart(df)
            if duplicates_trace:
                charts.append(duplicates_trace)
            
            # Gráfico de tipos de datos
            types_trace = self._create_data_types_chart(df)
            if types_trace:
                charts.append(types_trace)
        
        except Exception as e:
            logger.error(f"Error generating data quality charts: {e}")
        
        return charts
    
    def _create_histogram(self, df: pd.DataFrame, column: str) -> Optional[ChartTrace]:
        """Crea un histograma para una columna numérica"""
        try:
            data = df[column].dropna()
            if len(data) == 0:
                return None
            
            # Aplicar muestreo si es necesario
            if len(data) > self.max_bins * 10:
                data = data.sample(n=min(len(data), self.max_bins * 10))
            
            # Crear histograma
            fig = px.histogram(
                x=data,
                nbins=min(self.max_bins, len(data) // 5),
                title=f"Distribución de {column}",
                labels={'x': column, 'y': 'Frecuencia'}
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width,
                showlegend=False
            )
            
            return ChartTrace(
                chart_id=f"hist_{column}",
                chart_type=ChartType.HISTOGRAM,
                title=f"Distribución de {column}",
                description=f"Histograma mostrando la distribución de valores en {column}",
                plotly_json=json.loads(fig.to_json()),
                column_name=column
            )
        
        except Exception as e:
            logger.error(f"Error creating histogram for {column}: {e}")
            return None
    
    def _create_boxplot(self, df: pd.DataFrame, column: str) -> Optional[ChartTrace]:
        """Crea un box plot para una columna numérica"""
        try:
            data = df[column].dropna()
            if len(data) == 0:
                return None
            
            # Aplicar muestreo si es necesario
            if len(data) > 10000:
                data = data.sample(n=10000)
            
            fig = px.box(
                y=data,
                title=f"Box Plot de {column}",
                labels={'y': column}
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width,
                showlegend=False
            )
            
            return ChartTrace(
                chart_id=f"box_{column}",
                chart_type=ChartType.BOXPLOT,
                title=f"Box Plot de {column}",
                description=f"Box plot mostrando la distribución y outliers de {column}",
                plotly_json=json.loads(fig.to_json()),
                column_name=column
            )
        
        except Exception as e:
            logger.error(f"Error creating boxplot for {column}: {e}")
            return None
    
    def _create_qq_plot(self, df: pd.DataFrame, column: str) -> Optional[ChartTrace]:
        """Crea un Q-Q plot para verificar normalidad"""
        try:
            data = df[column].dropna()
            if len(data) < 10:
                return None
            
            # Aplicar muestreo si es necesario
            if len(data) > 1000:
                data = data.sample(n=1000)
            
            # Calcular cuantiles teóricos
            from scipy import stats
            theoretical_quantiles = stats.probplot(data, dist="norm")[0][0]
            sample_quantiles = stats.probplot(data, dist="norm")[0][1]
            
            fig = go.Figure()
            
            fig.add_trace(go.Scatter(
                x=theoretical_quantiles,
                y=sample_quantiles,
                mode='markers',
                name='Datos',
                marker=dict(size=6)
            ))
            
            # Línea de referencia (y=x)
            min_val = min(theoretical_quantiles.min(), sample_quantiles.min())
            max_val = max(theoretical_quantiles.max(), sample_quantiles.max())
            fig.add_trace(go.Scatter(
                x=[min_val, max_val],
                y=[min_val, max_val],
                mode='lines',
                name='Normal',
                line=dict(dash='dash', color='red')
            ))
            
            fig.update_layout(
                title=f"Q-Q Plot de {column}",
                xaxis_title="Cuantiles Teóricos (Normal)",
                yaxis_title="Cuantiles de la Muestra",
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id=f"qq_{column}",
                chart_type=ChartType.QQPLOT,
                title=f"Q-Q Plot de {column}",
                description=f"Q-Q plot para verificar si {column} sigue una distribución normal",
                plotly_json=json.loads(fig.to_json()),
                column_name=column
            )
        
        except Exception as e:
            logger.error(f"Error creating Q-Q plot for {column}: {e}")
            return None
    
    def _create_bar_chart(self, df: pd.DataFrame, column: str) -> Optional[ChartTrace]:
        """Crea un gráfico de barras para una columna categórica"""
        try:
            data = df[column].value_counts().head(20)  # Top 20 categorías
            
            if len(data) == 0:
                return None
            
            fig = px.bar(
                x=data.index,
                y=data.values,
                title=f"Frecuencia de {column}",
                labels={'x': column, 'y': 'Frecuencia'}
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width,
                xaxis_tickangle=-45
            )
            
            return ChartTrace(
                chart_id=f"bar_{column}",
                chart_type=ChartType.BAR,
                title=f"Frecuencia de {column}",
                description=f"Gráfico de barras mostrando la frecuencia de cada categoría en {column}",
                plotly_json=json.loads(fig.to_json()),
                column_name=column
            )
        
        except Exception as e:
            logger.error(f"Error creating bar chart for {column}: {e}")
            return None
    
    def _create_pie_chart(self, df: pd.DataFrame, column: str) -> Optional[ChartTrace]:
        """Crea un gráfico de pie para una columna categórica"""
        try:
            data = df[column].value_counts().head(10)  # Top 10 categorías
            
            if len(data) == 0:
                return None
            
            fig = px.pie(
                values=data.values,
                names=data.index,
                title=f"Distribución de {column}"
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id=f"pie_{column}",
                chart_type=ChartType.PIE,
                title=f"Distribución de {column}",
                description=f"Gráfico de pie mostrando la distribución porcentual de {column}",
                plotly_json=json.loads(fig.to_json()),
                column_name=column
            )
        
        except Exception as e:
            logger.error(f"Error creating pie chart for {column}: {e}")
            return None
    
    def _create_correlation_heatmap(self, corr_matrix: pd.DataFrame) -> Optional[ChartTrace]:
        """Crea un heatmap de correlaciones"""
        try:
            if corr_matrix.empty:
                return None
            
            fig = px.imshow(
                corr_matrix,
                title="Matriz de Correlación",
                color_continuous_scale='RdBu',
                aspect='auto'
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id="corr_heatmap",
                chart_type=ChartType.HEATMAP,
                title="Matriz de Correlación",
                description="Heatmap mostrando las correlaciones entre variables numéricas",
                plotly_json=json.loads(fig.to_json()),
                column_name="correlation"
            )
        
        except Exception as e:
            logger.error(f"Error creating correlation heatmap: {e}")
            return None
    
    def _find_strong_correlations(self, corr_matrix: pd.DataFrame) -> List[Tuple[str, str, float]]:
        """Encuentra correlaciones fuertes (|r| > 0.5)"""
        strong_corrs = []
        
        try:
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    corr_value = corr_matrix.iloc[i, j]
                    if abs(corr_value) > 0.5:
                        col1 = corr_matrix.columns[i]
                        col2 = corr_matrix.columns[j]
                        strong_corrs.append((col1, col2, corr_value))
            
            # Ordenar por valor absoluto de correlación
            strong_corrs.sort(key=lambda x: abs(x[2]), reverse=True)
            
        except Exception as e:
            logger.error(f"Error finding strong correlations: {e}")
        
        return strong_corrs
    
    def _create_scatter_plot(self, df: pd.DataFrame, col1: str, col2: str, corr_value: float) -> Optional[ChartTrace]:
        """Crea un scatter plot para dos variables correlacionadas"""
        try:
            data = df[[col1, col2]].dropna()
            if len(data) == 0:
                return None
            
            # Aplicar muestreo si es necesario
            if len(data) > 5000:
                data = data.sample(n=5000)
            
            fig = px.scatter(
                data,
                x=col1,
                y=col2,
                title=f"Correlación entre {col1} y {col2} (r={corr_value:.3f})",
                labels={'x': col1, 'y': col2}
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id=f"scatter_{col1}_{col2}",
                chart_type=ChartType.SCATTER,
                title=f"Correlación entre {col1} y {col2}",
                description=f"Scatter plot mostrando la relación entre {col1} y {col2} (r={corr_value:.3f})",
                plotly_json=json.loads(fig.to_json()),
                column_name=f"{col1}_{col2}"
            )
        
        except Exception as e:
            logger.error(f"Error creating scatter plot for {col1} vs {col2}: {e}")
            return None
    
    def _create_time_series_line(self, df: pd.DataFrame, time_col: str, value_col: str) -> Optional[ChartTrace]:
        """Crea un gráfico de línea para series de tiempo"""
        try:
            data = df[[time_col, value_col]].dropna()
            if len(data) == 0:
                return None
            
            # Aplicar muestreo si es necesario
            if len(data) > self.max_time_series_points:
                data = data.sample(n=self.max_time_series_points).sort_values(time_col)
            
            fig = px.line(
                data,
                x=time_col,
                y=value_col,
                title=f"Serie Temporal de {value_col}",
                labels={'x': 'Fecha', 'y': value_col}
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id=f"timeseries_{value_col}",
                chart_type=ChartType.LINE,
                title=f"Serie Temporal de {value_col}",
                description=f"Gráfico de línea mostrando la evolución temporal de {value_col}",
                plotly_json=json.loads(fig.to_json()),
                column_name=value_col
            )
        
        except Exception as e:
            logger.error(f"Error creating time series line for {value_col}: {e}")
            return None
    
    def _create_trend_chart(self, df: pd.DataFrame, time_col: str, value_col: Optional[str]) -> Optional[ChartTrace]:
        """Crea un gráfico de tendencia"""
        if not value_col:
            return None
        
        try:
            data = df[[time_col, value_col]].dropna()
            if len(data) == 0:
                return None
            
            # Aplicar muestreo si es necesario
            if len(data) > self.max_time_series_points:
                data = data.sample(n=self.max_time_series_points).sort_values(time_col)
            
            # Agregar línea de tendencia
            fig = px.scatter(
                data,
                x=time_col,
                y=value_col,
                title=f"Tendencia de {value_col}",
                labels={'x': 'Fecha', 'y': value_col}
            )
            
            # Agregar línea de tendencia
            z = np.polyfit(range(len(data)), data[value_col], 1)
            p = np.poly1d(z)
            fig.add_trace(go.Scatter(
                x=data[time_col],
                y=p(range(len(data))),
                mode='lines',
                name='Tendencia',
                line=dict(color='red', dash='dash')
            ))
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id=f"trend_{value_col}",
                chart_type=ChartType.SCATTER,
                title=f"Tendencia de {value_col}",
                description=f"Gráfico de dispersión con línea de tendencia para {value_col}",
                plotly_json=json.loads(fig.to_json()),
                column_name=value_col
            )
        
        except Exception as e:
            logger.error(f"Error creating trend chart for {value_col}: {e}")
            return None
    
    def _create_missing_values_chart(self, df: pd.DataFrame) -> Optional[ChartTrace]:
        """Crea un gráfico de valores faltantes"""
        try:
            missing_data = df.isnull().sum()
            missing_data = missing_data[missing_data > 0]
            
            if len(missing_data) == 0:
                return None
            
            fig = px.bar(
                x=missing_data.index,
                y=missing_data.values,
                title="Valores Faltantes por Columna",
                labels={'x': 'Columna', 'y': 'Cantidad de Valores Faltantes'}
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width,
                xaxis_tickangle=-45
            )
            
            return ChartTrace(
                chart_id="missing_values",
                chart_type=ChartType.BAR,
                title="Valores Faltantes por Columna",
                description="Gráfico de barras mostrando la cantidad de valores faltantes en cada columna",
                plotly_json=json.loads(fig.to_json()),
                column_name="missing_values"
            )
        
        except Exception as e:
            logger.error(f"Error creating missing values chart: {e}")
            return None
    
    def _create_duplicates_chart(self, df: pd.DataFrame) -> Optional[ChartTrace]:
        """Crea un gráfico de duplicados"""
        try:
            # Contar duplicados por fila
            duplicate_counts = df.duplicated(keep=False).value_counts()
            
            if len(duplicate_counts) == 0:
                return None
            
            fig = px.pie(
                values=duplicate_counts.values,
                names=['Sin Duplicados' if i else 'Con Duplicados' for i in duplicate_counts.index],
                title="Distribución de Filas Duplicadas"
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id="duplicates",
                chart_type=ChartType.PIE,
                title="Distribución de Filas Duplicadas",
                description="Gráfico de pie mostrando la proporción de filas duplicadas vs únicas",
                plotly_json=json.loads(fig.to_json()),
                column_name="duplicates"
            )
        
        except Exception as e:
            logger.error(f"Error creating duplicates chart: {e}")
            return None
    
    def _create_data_types_chart(self, df: pd.DataFrame) -> Optional[ChartTrace]:
        """Crea un gráfico de tipos de datos"""
        try:
            type_counts = df.dtypes.value_counts()
            
            if len(type_counts) == 0:
                return None
            
            fig = px.pie(
                values=type_counts.values,
                names=type_counts.index.astype(str),
                title="Distribución de Tipos de Datos"
            )
            
            fig.update_layout(
                height=self.chart_height,
                width=self.chart_width
            )
            
            return ChartTrace(
                chart_id="data_types",
                chart_type=ChartType.PIE,
                title="Distribución de Tipos de Datos",
                description="Gráfico de pie mostrando la distribución de tipos de datos en el dataset",
                plotly_json=json.loads(fig.to_json()),
                column_name="data_types"
            )
        
        except Exception as e:
            logger.error(f"Error creating data types chart: {e}")
            return None
    
    def export_chart_to_png(self, chart_trace: ChartTrace, output_path: Path) -> bool:
        """
        Exporta un gráfico a PNG
        
        Args:
            chart_trace: Traza del gráfico
            output_path: Ruta de salida para el PNG
            
        Returns:
            True si se exportó correctamente
        """
        try:
            # Recrear figura desde JSON
            fig = go.Figure(chart_trace.plotly_json)
            
            # Exportar a PNG
            fig.write_image(
                str(output_path),
                width=self.chart_width,
                height=self.chart_height,
                scale=2  # Alta resolución
            )
            
            logger.info(f"Chart exported to PNG: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting chart to PNG: {e}")
            return False


# Instancia global del servicio
charts_service = ChartsService()
