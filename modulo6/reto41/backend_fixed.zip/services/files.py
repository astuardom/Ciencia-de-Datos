import os
import shutil
from typing import Optional, Tuple, List, Dict, Any
from pathlib import Path
import pandas as pd
import openpyxl
from fastapi import UploadFile, HTTPException
import logging
from datetime import datetime, timedelta
import mimetypes
import re

from core.config import settings
from core.models import FileType, generate_dataset_id

logger = logging.getLogger(__name__)


class FileService:
    """Servicio para manejo de archivos (validación, guardado, procesamiento)"""
    
    def __init__(self):
        self.uploads_dir = settings.uploads_dir
        self.supported_extensions = {'.csv', '.xlsx', '.xls'}
        self.max_file_size = settings.MAX_FILE_SIZE
        
        # Mapeo de tipos MIME
        self.mime_types = {
            'text/csv': '.csv',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
            'application/vnd.ms-excel': '.xls',
            'application/octet-stream': None  # Se detectará por extensión
        }
    
    def validate_file(self, file: UploadFile) -> Tuple[bool, str, FileType]:
        """
        Valida un archivo subido
        
        Args:
            file: Archivo subido
            
        Returns:
            Tuple de (es_válido, mensaje_error, tipo_archivo)
        """
        try:
            # Verificar tamaño
            if file.size and file.size > self.max_file_size:
                max_size_mb = self.max_file_size / (1024 * 1024)
                return False, f"El archivo excede el tamaño máximo de {max_size_mb}MB", None
            
            # Verificar extensión
            file_extension = Path(file.filename).suffix.lower()
            if file_extension not in self.supported_extensions:
                supported = ', '.join(self.supported_extensions)
                return False, f"Extensión no soportada. Soportadas: {supported}", None
            
            # Verificar tipo MIME
            if file.content_type and file.content_type in self.mime_types:
                expected_extension = self.mime_types[file.content_type]
                if expected_extension and file_extension != expected_extension:
                    return False, f"Tipo MIME no coincide con la extensión del archivo", None
            
            # Determinar tipo de archivo
            if file_extension == '.csv':
                file_type = FileType.CSV
            elif file_extension in ['.xlsx', '.xls']:
                file_type = FileType.EXCEL
            else:
                return False, "Tipo de archivo no reconocido", None
            
            return True, "", file_type
            
        except Exception as e:
            logger.error(f"Error validating file: {e}")
            return False, f"Error al validar el archivo: {str(e)}", None
    
    def save_file(self, file: UploadFile, dataset_id: str) -> Path:
        """
        Guarda un archivo subido
        
        Args:
            file: Archivo subido
            dataset_id: ID del dataset
            
        Returns:
            Ruta donde se guardó el archivo
        """
        try:
            # Crear directorio del dataset
            dataset_dir = self.uploads_dir / dataset_id
            dataset_dir.mkdir(exist_ok=True)
            
            # Generar nombre de archivo seguro
            safe_filename = self._sanitize_filename(file.filename)
            file_path = dataset_dir / safe_filename
            
            # Guardar archivo
            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            
            logger.info(f"File saved: {file_path}")
            return file_path
            
        except Exception as e:
            logger.error(f"Error saving file: {e}")
            raise HTTPException(status_code=500, detail=f"Error al guardar el archivo: {str(e)}")
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitiza el nombre del archivo para evitar problemas de seguridad"""
        # Remover caracteres peligrosos
        safe_name = re.sub(r'[<>:"/\\|?*]', '_', filename)
        
        # Limitar longitud
        if len(safe_name) > 255:
            name, ext = os.path.splitext(safe_name)
            safe_name = name[:255-len(ext)] + ext
        
        return safe_name
    
    def get_excel_sheets(self, file_path: Path) -> List[Dict[str, Any]]:
        """
        Obtiene información sobre las hojas de un archivo Excel
        
        Args:
            file_path: Ruta al archivo Excel
            
        Returns:
            Lista de información de hojas
        """
        try:
            workbook = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
            sheets_info = []
            
            for sheet_name in workbook.sheetnames:
                worksheet = workbook[sheet_name]
                
                # Contar celdas no vacías
                non_empty_cells = 0
                total_cells = 0
                
                for row in worksheet.iter_rows():
                    for cell in row:
                        total_cells += 1
                        if cell.value is not None:
                            non_empty_cells += 1
                
                # Calcular densidad
                density = (non_empty_cells / total_cells * 100) if total_cells > 0 else 0
                
                sheets_info.append({
                    'name': sheet_name,
                    'non_empty_cells': non_empty_cells,
                    'total_cells': total_cells,
                    'density': round(density, 2),
                    'recommended': density > 10  # Recomendar si tiene más del 10% de densidad
                })
            
            workbook.close()
            
            # Ordenar por densidad (mayor a menor)
            sheets_info.sort(key=lambda x: x['density'], reverse=True)
            
            return sheets_info
            
        except Exception as e:
            logger.error(f"Error reading Excel sheets: {e}")
            return []
    
    def select_best_sheet(self, file_path: Path, sheet_name: Optional[str] = None) -> str:
        """
        Selecciona la mejor hoja de un archivo Excel
        
        Args:
            file_path: Ruta al archivo Excel
            sheet_name: Nombre específico de hoja (opcional)
            
        Returns:
            Nombre de la hoja seleccionada
        """
        try:
            sheets_info = self.get_excel_sheets(file_path)
            
            if not sheets_info:
                raise ValueError("No se pudieron leer las hojas del archivo Excel")
            
            # Si se especifica una hoja, verificar que existe
            if sheet_name:
                sheet_names = [s['name'] for s in sheets_info]
                if sheet_name not in sheet_names:
                    raise ValueError(f"La hoja '{sheet_name}' no existe en el archivo")
                return sheet_name
            
            # Seleccionar la hoja con mayor densidad
            best_sheet = sheets_info[0]
            
            if best_sheet['density'] < 5:
                logger.warning(f"La mejor hoja tiene baja densidad: {best_sheet['density']}%")
            
            logger.info(f"Selected sheet: {best_sheet['name']} (density: {best_sheet['density']}%)")
            return best_sheet['name']
            
        except Exception as e:
            logger.error(f"Error selecting best sheet: {e}")
            raise
    
    def read_file(self, file_path: Path, sheet_name: Optional[str] = None) -> pd.DataFrame:
        """
        Lee un archivo (CSV o Excel) y retorna un DataFrame
        
        Args:
            file_path: Ruta al archivo
            sheet_name: Nombre de la hoja (solo para Excel)
            
        Returns:
            DataFrame con los datos
        """
        try:
            file_extension = file_path.suffix.lower()
            
            if file_extension == '.csv':
                # Intentar diferentes encodings y separadores
                df = self._read_csv_with_fallback(file_path)
            elif file_extension in ['.xlsx', '.xls']:
                if not sheet_name:
                    sheet_name = self.select_best_sheet(file_path)
                df = pd.read_excel(file_path, sheet_name=sheet_name, engine='openpyxl')
            else:
                raise ValueError(f"Tipo de archivo no soportado: {file_extension}")
            
            # Limpiar datos básicos
            df = self._clean_dataframe(df)
            
            logger.info(f"File read successfully: {len(df)} rows, {len(df.columns)} columns")
            return df
            
        except Exception as e:
            logger.error(f"Error reading file: {e}")
            raise HTTPException(status_code=500, detail=f"Error al leer el archivo: {str(e)}")
    
    def _read_csv_with_fallback(self, file_path: Path) -> pd.DataFrame:
        """Lee un CSV con fallbacks para encoding y separador"""
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        separators = [',', ';', '\t', '|']
        
        for encoding in encodings:
            for sep in separators:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, sep=sep, low_memory=False)
                    if len(df.columns) > 1:  # Verificar que se detectaron múltiples columnas
                        logger.info(f"CSV read with encoding={encoding}, separator='{sep}'")
                        return df
                except Exception:
                    continue
        
        # Si todos fallan, intentar con pandas auto-detection
        try:
            df = pd.read_csv(file_path, low_memory=False)
            return df
        except Exception as e:
            raise ValueError(f"No se pudo leer el archivo CSV con ningún encoding o separador: {e}")
    
    def _clean_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """Limpia el DataFrame básico"""
        # Remover filas completamente vacías
        df = df.dropna(how='all')
        
        # Remover columnas completamente vacías
        df = df.dropna(axis=1, how='all')
        
        # Limpiar nombres de columnas
        df.columns = [self._clean_column_name(col) for col in df.columns]
        
        # Resetear índice
        df = df.reset_index(drop=True)
        
        return df
    
    def _clean_column_name(self, column_name: str) -> str:
        """Limpia el nombre de una columna"""
        if pd.isna(column_name):
            return "unnamed_column"
        
        # Convertir a string
        col_str = str(column_name).strip()
        
        # Remover caracteres especiales
        col_str = re.sub(r'[^\w\s]', '_', col_str)
        
        # Reemplazar espacios con guiones bajos
        col_str = re.sub(r'\s+', '_', col_str)
        
        # Convertir a snake_case
        col_str = col_str.lower()
        
        # Remover guiones bajos múltiples
        col_str = re.sub(r'_+', '_', col_str)
        
        # Remover guiones bajos al inicio y final
        col_str = col_str.strip('_')
        
        # Si quedó vacío, usar nombre por defecto
        if not col_str:
            col_str = "unnamed_column"
        
        return col_str
    
    def get_file_info(self, file_path: Path) -> Dict[str, Any]:
        """
        Obtiene información básica de un archivo
        
        Args:
            file_path: Ruta al archivo
            
        Returns:
            Información del archivo
        """
        try:
            stat = file_path.stat()
            
            return {
                'filename': file_path.name,
                'size_bytes': stat.st_size,
                'size_mb': round(stat.st_size / (1024 * 1024), 2),
                'created_at': datetime.fromtimestamp(stat.st_ctime),
                'modified_at': datetime.fromtimestamp(stat.st_mtime),
                'extension': file_path.suffix.lower(),
                'path': str(file_path)
            }
            
        except Exception as e:
            logger.error(f"Error getting file info: {e}")
            return {}
    
    def delete_dataset_files(self, dataset_id: str) -> bool:
        """
        Elimina todos los archivos de un dataset
        
        Args:
            dataset_id: ID del dataset
            
        Returns:
            True si se eliminaron exitosamente
        """
        try:
            dataset_dir = self.uploads_dir / dataset_id
            if dataset_dir.exists():
                shutil.rmtree(dataset_dir)
                logger.info(f"Deleted dataset files: {dataset_dir}")
                return True
            return False
            
        except Exception as e:
            logger.error(f"Error deleting dataset files: {e}")
            return False
    
    def cleanup_old_files(self, max_age_days: int = None) -> int:
        """
        Limpia archivos antiguos
        
        Args:
            max_age_days: Edad máxima en días (usa configuración por defecto si es None)
            
        Returns:
            Número de archivos eliminados
        """
        try:
            if max_age_days is None:
                max_age_days = settings.ARTIFACT_TTL_DAYS
            
            cutoff_time = datetime.now() - timedelta(days=max_age_days)
            deleted_count = 0
            
            for dataset_dir in self.uploads_dir.iterdir():
                if not dataset_dir.is_dir():
                    continue
                
                # Verificar si el directorio es antiguo
                dir_stat = dataset_dir.stat()
                dir_modified = datetime.fromtimestamp(dir_stat.st_mtime)
                
                if dir_modified < cutoff_time:
                    try:
                        shutil.rmtree(dataset_dir)
                        deleted_count += 1
                        logger.info(f"Cleaned up old dataset directory: {dataset_dir}")
                    except Exception as e:
                        logger.error(f"Error cleaning up directory {dataset_dir}: {e}")
            
            return deleted_count
            
        except Exception as e:
            logger.error(f"Error in cleanup_old_files: {e}")
            return 0


# Instancia global del servicio de archivos
file_service = FileService()
