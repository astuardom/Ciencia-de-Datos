import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional
import logging
from pathlib import Path
from datetime import datetime
import json
from jinja2 import Environment, FileSystemLoader, Template
import weasyprint
from weasyprint import HTML, CSS
import tempfile
import os

from core.config import settings
from core.models import Language, InsightSection

logger = logging.getLogger(__name__)


class ReportService:
    """Servicio de generación de reportes HTML y PDF"""
    
    def __init__(self):
        self.template_dir = settings.templates_dir
        self.artifacts_dir = settings.artifacts_dir
        self.enable_pdf = settings.ENABLE_PDF
        
        # Configurar Jinja2
        self.jinja_env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=True
        )
        
        # Cargar plantilla base
        self.base_template = self._load_base_template()
    
    def generate_report(self, dataset_id: str, profile: Dict[str, Any], 
                       insights: List[InsightSection], language: Language = Language.ES) -> Dict[str, str]:
        """
        Genera reporte completo en HTML y PDF
        
        Args:
            dataset_id: ID del dataset
            profile: Perfil completo del dataset
            insights: Lista de insights generados
            language: Idioma del reporte
            
        Returns:
            Diccionario con rutas a los archivos generados
        """
        try:
            logger.info(f"Generating report for dataset {dataset_id} in {language}")
            
            # Preparar datos para la plantilla
            template_data = self._prepare_template_data(dataset_id, profile, insights, language)
            
            # Generar HTML
            html_content = self._generate_html(template_data)
            html_path = self._save_html(dataset_id, html_content)
            
            # Generar PDF si está habilitado
            pdf_path = None
            if self.enable_pdf:
                pdf_path = self._generate_pdf(html_content, dataset_id)
            
            result = {
                'html_path': str(html_path),
                'html_url': f"/artifacts/{dataset_id}_report.html"
            }
            
            if pdf_path:
                result['pdf_path'] = str(pdf_path)
                result['pdf_url'] = f"/artifacts/{dataset_id}_report.pdf"
            
            logger.info(f"Report generated successfully for dataset {dataset_id}")
            return result
            
        except Exception as e:
            logger.error(f"Error generating report: {e}")
            raise
    
    def _load_base_template(self) -> Template:
        """Carga la plantilla base del reporte"""
        try:
            template_path = self.template_dir / "report.html"
            if template_path.exists():
                return self.jinja_env.get_template("report.html")
            else:
                # Crear plantilla por defecto si no existe
                return self._create_default_template()
        except Exception as e:
            logger.error(f"Error loading template: {e}")
            return self._create_default_template()
    
    def _create_default_template(self) -> Template:
        """Crea una plantilla por defecto si no existe el archivo"""
        default_template = """
<!DOCTYPE html>
<html lang="{{ language }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Análisis - {{ dataset_id }}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
        .section { margin-bottom: 30px; }
        .section h2 { color: #2c3e50; border-left: 4px solid #3498db; padding-left: 15px; }
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
        .kpi-card { background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; border: 1px solid #dee2e6; }
        .kpi-value { font-size: 2em; font-weight: bold; color: #3498db; }
        .kpi-label { color: #6c757d; margin-top: 5px; }
        .insight-item { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .chart-container { margin: 20px 0; text-align: center; }
        .chart-placeholder { background: #e9ecef; padding: 40px; border-radius: 5px; color: #6c757d; }
        .footer { margin-top: 50px; text-align: center; color: #6c757d; border-top: 1px solid #dee2e6; padding-top: 20px; }
        @media print { body { margin: 20px; } .kpi-grid { grid-template-columns: repeat(3, 1fr); } }
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 Reporte de Análisis de Datos</h1>
        <p><strong>Dataset:</strong> {{ dataset_id }} | <strong>Generado:</strong> {{ generated_at }}</p>
    </div>

    <div class="section">
        <h2>📈 Resumen Ejecutivo</h2>
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-value">{{ summary.total_rows | default(0) | number }}</div>
                <div class="kpi-label">Filas</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-value">{{ summary.total_columns | default(0) | number }}</div>
                <div class="kpi-label">Columnas</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-value">{{ summary.data_quality_score | default(0) | round(1) }}%</div>
                <div class="kpi-label">Calidad</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-value">{{ summary.completeness_score | default(0) | round(1) }}%</div>
                <div class="kpi-label">Completitud</div>
            </div>
        </div>
    </div>

    {% if insights %}
    <div class="section">
        <h2>🔍 Insights Generados</h2>
        {% for section in insights %}
        <div class="section">
            <h3>{{ section.title }}</h3>
            {% for insight in section.insights %}
            <div class="insight-item">{{ insight }}</div>
            {% endfor %}
        </div>
        {% endfor %}
    </div>
    {% endif %}

    {% if charts %}
    <div class="section">
        <h2>📊 Gráficos Generados</h2>
        <p>Se generaron {{ charts | length }} gráficos interactivos. Los gráficos están disponibles en formato JSON para integración con herramientas de visualización.</p>
        <div class="chart-container">
            <div class="chart-placeholder">
                📈 {{ charts | length }} gráficos disponibles
            </div>
        </div>
    </div>
    {% endif %}

    <div class="footer">
        <p>Reporte generado automáticamente por AnalizadorDatos API v2.0</p>
        <p>Fecha de generación: {{ generated_at }}</p>
    </div>
</body>
</html>
        """
        return Template(default_template)
    
    def _prepare_template_data(self, dataset_id: str, profile: Dict[str, Any], 
                              insights: List[InsightSection], language: Language) -> Dict[str, Any]:
        """Prepara los datos para la plantilla"""
        try:
            summary = profile.get('summary', {})
            columns = profile.get('columns', [])
            charts = profile.get('charts', [])
            
            # Determinar idioma
            lang = language.value if hasattr(language, 'value') else language
            is_spanish = lang == 'es'
            
            # Traducir textos según idioma
            translations = self._get_translations(lang)
            
            template_data = {
                'dataset_id': dataset_id,
                'language': lang,
                'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'summary': summary,
                'columns': columns,
                'charts': charts,
                'insights': insights,
                'translations': translations,
                'is_spanish': is_spanish
            }
            
            return template_data
            
        except Exception as e:
            logger.error(f"Error preparing template data: {e}")
            return {
                'dataset_id': dataset_id,
                'language': language,
                'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'summary': {},
                'columns': [],
                'charts': [],
                'insights': [],
                'translations': {},
                'is_spanish': True
            }
    
    def _get_translations(self, language: str) -> Dict[str, str]:
        """Obtiene traducciones según el idioma"""
        if language == 'en':
            return {
                'title': 'Data Analysis Report',
                'dataset': 'Dataset',
                'generated': 'Generated',
                'rows': 'Rows',
                'columns': 'Columns',
                'quality': 'Quality',
                'completeness': 'Completeness',
                'executive_summary': 'Executive Summary',
                'generated_insights': 'Generated Insights',
                'generated_charts': 'Generated Charts',
                'charts_available': 'charts available',
                'footer_text': 'Report automatically generated by Data Analyzer API v2.0',
                'generation_date': 'Generation date'
            }
        else:
            return {
                'title': 'Reporte de Análisis de Datos',
                'dataset': 'Dataset',
                'generated': 'Generado',
                'rows': 'Filas',
                'columns': 'Columnas',
                'quality': 'Calidad',
                'completeness': 'Completitud',
                'executive_summary': 'Resumen Ejecutivo',
                'generated_insights': 'Insights Generados',
                'generated_charts': 'Gráficos Generados',
                'charts_available': 'gráficos disponibles',
                'footer_text': 'Reporte generado automáticamente por AnalizadorDatos API v2.0',
                'generation_date': 'Fecha de generación'
            }
    
    def _generate_html(self, template_data: Dict[str, Any]) -> str:
        """Genera el contenido HTML del reporte"""
        try:
            html_content = self.base_template.render(**template_data)
            return html_content
        except Exception as e:
            logger.error(f"Error generating HTML: {e}")
            # Fallback a contenido básico
            return self._generate_fallback_html(template_data)
    
    def _generate_fallback_html(self, template_data: Dict[str, Any]) -> str:
        """Genera HTML básico como fallback"""
        return f"""
<!DOCTYPE html>
<html lang="{template_data.get('language', 'es')}">
<head>
    <meta charset="UTF-8">
    <title>Reporte - {template_data.get('dataset_id', 'N/A')}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        .header {{ text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; }}
        .section {{ margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Análisis</h1>
        <p>Dataset: {template_data.get('dataset_id', 'N/A')}</p>
        <p>Generado: {template_data.get('generated_at', 'N/A')}</p>
    </div>
    
    <div class="section">
        <h2>Resumen</h2>
        <p>Filas: {template_data.get('summary', {}).get('total_rows', 0)}</p>
        <p>Columnas: {template_data.get('summary', {}).get('total_columns', 0)}</p>
        <p>Calidad: {template_data.get('summary', {}).get('data_quality_score', 0)}%</p>
    </div>
    
    <div class="section">
        <h2>Insights</h2>
        <p>Se generaron {len(template_data.get('insights', []))} secciones de insights.</p>
    </div>
</body>
</html>
        """
    
    def _save_html(self, dataset_id: str, html_content: str) -> Path:
        """Guarda el reporte HTML"""
        try:
            filename = f"{dataset_id}_report.html"
            file_path = self.artifacts_dir / filename
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            logger.info(f"HTML report saved to {file_path}")
            return file_path
            
        except Exception as e:
            logger.error(f"Error saving HTML report: {e}")
            raise
    
    def _generate_pdf(self, html_content: str, dataset_id: str) -> Optional[Path]:
        """Genera el reporte PDF desde HTML"""
        try:
            if not self.enable_pdf:
                return None
            
            filename = f"{dataset_id}_report.pdf"
            file_path = self.artifacts_dir / filename
            
            # Crear archivo HTML temporal
            with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as temp_html:
                temp_html.write(html_content)
                temp_html_path = temp_html.name
            
            try:
                # Convertir HTML a PDF
                html_doc = HTML(filename=temp_html_path)
                html_doc.write_pdf(str(file_path))
                
                logger.info(f"PDF report generated: {file_path}")
                return file_path
                
            finally:
                # Limpiar archivo temporal
                os.unlink(temp_html_path)
                
        except Exception as e:
            logger.error(f"Error generating PDF: {e}")
            return None
    
    def generate_custom_report(self, dataset_id: str, profile: Dict[str, Any], 
                              sections: List[str], language: Language = Language.ES) -> Dict[str, str]:
        """
        Genera reporte personalizado con secciones específicas
        
        Args:
            dataset_id: ID del dataset
            profile: Perfil del dataset
            sections: Lista de secciones a incluir
            language: Idioma del reporte
            
        Returns:
            Diccionario con rutas a los archivos generados
        """
        try:
            logger.info(f"Generating custom report for dataset {dataset_id} with sections: {sections}")
            
            # Filtrar insights por secciones solicitadas
            all_insights = self._generate_all_insights(profile, language)
            filtered_insights = [
                insight for insight in all_insights 
                if insight.section_type.value in sections
            ]
            
            # Generar reporte con secciones filtradas
            return self.generate_report(dataset_id, profile, filtered_insights, language)
            
        except Exception as e:
            logger.error(f"Error generating custom report: {e}")
            raise
    
    def _generate_all_insights(self, profile: Dict[str, Any], language: Language) -> List[InsightSection]:
        """Genera todos los insights disponibles"""
        try:
            from services.insights import insights_service
            return insights_service.generate_insights(profile, language)
        except Exception as e:
            logger.error(f"Error generating insights: {e}")
            return []
    
    def get_report_template(self, language: Language = Language.ES) -> str:
        """Obtiene la plantilla del reporte en el idioma especificado"""
        try:
            template_path = self.template_dir / f"report_{language.value}.html"
            if template_path.exists():
                with open(template_path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                return self.base_template.render(language=language.value)
        except Exception as e:
            logger.error(f"Error getting report template: {e}")
            return ""


# Instancia global del servicio
report_service = ReportService()
