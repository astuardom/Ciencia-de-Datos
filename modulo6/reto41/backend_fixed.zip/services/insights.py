import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime

from core.config import settings
from core.models import InsightSection, InsightType, Language

logger = logging.getLogger(__name__)


class InsightsService:
    """Servicio de generación de insights automáticos basados en reglas"""
    
    def __init__(self):
        self.correlation_threshold = settings.CORRELATION_THRESHOLD
        self.outlier_threshold = settings.OUTLIER_THRESHOLD
        
        # Reglas de insights en español e inglés
        self.insight_rules = {
            'es': {
                'data_quality': self._get_es_data_quality_rules(),
                'distributions': self._get_es_distribution_rules(),
                'relationships': self._get_es_relationship_rules(),
                'anomalies': self._get_es_anomaly_rules(),
                'recommendations': self._get_es_recommendation_rules()
            },
            'en': {
                'data_quality': self._get_en_data_quality_rules(),
                'distributions': self._get_en_distribution_rules(),
                'relationships': self._get_en_relationship_rules(),
                'anomalies': self._get_en_anomaly_rules(),
                'recommendations': self._get_en_recommendation_rules()
            }
        }
    
    def generate_insights(self, profile: Dict[str, Any], language: Language = Language.ES) -> List[InsightSection]:
        """
        Genera insights automáticos basados en el perfil del dataset
        
        Args:
            profile: Perfil del dataset
            language: Idioma para los insights
            
        Returns:
            Lista de secciones de insights
        """
        try:
            lang = language.value if hasattr(language, 'value') else language
            
            insights = []
            
            # Insights de calidad de datos
            quality_insights = self._generate_data_quality_insights(profile, lang)
            insights.append(quality_insights)
            
            # Insights de distribuciones
            distribution_insights = self._generate_distribution_insights(profile, lang)
            insights.append(distribution_insights)
            
            # Insights de relaciones
            relationship_insights = self._generate_relationship_insights(profile, lang)
            insights.append(relationship_insights)
            
            # Insights de anomalías
            anomaly_insights = self._generate_anomaly_insights(profile, lang)
            insights.append(anomaly_insights)
            
            # Recomendaciones
            recommendation_insights = self._generate_recommendation_insights(profile, lang)
            insights.append(recommendation_insights)
            
            logger.info(f"Generated {len(insights)} insight sections in {lang}")
            return insights
            
        except Exception as e:
            logger.error(f"Error generating insights: {e}")
            return []
    
    def _generate_data_quality_insights(self, profile: Dict[str, Any], language: str) -> InsightSection:
        """Genera insights sobre la calidad de los datos"""
        try:
            summary = profile.get('summary', {})
            columns = profile.get('columns', [])
            
            rules = self.insight_rules[language]['data_quality']
            insights = []
            
            # Completitud general
            completeness = summary.get('completeness_score', 0)
            if completeness >= 90:
                insights.append(rules['high_completeness'].format(score=completeness))
            elif completeness >= 70:
                insights.append(rules['medium_completeness'].format(score=completeness))
            else:
                insights.append(rules['low_completeness'].format(score=completeness))
            
            # Consistencia
            consistency = summary.get('consistency_score', 0)
            if consistency >= 90:
                insights.append(rules['high_consistency'].format(score=consistency))
            elif consistency >= 70:
                insights.append(rules['medium_consistency'].format(score=consistency))
            else:
                insights.append(rules['low_consistency'].format(score=consistency))
            
            # Valores nulos
            null_columns = [col for col in columns if col.get('null_percentage', 0) > 20]
            if null_columns:
                insights.append(rules['high_null_values'].format(
                    count=len(null_columns),
                    columns=', '.join([col['name'] for col in null_columns[:3]])
                ))
            
            # Duplicados
            if summary.get('duplicate_rows', 0) > 0:
                duplicate_pct = (summary['duplicate_rows'] / summary['total_rows']) * 100
                insights.append(rules['duplicates_detected'].format(
                    count=summary['duplicate_rows'],
                    percentage=duplicate_pct
                ))
            
            return InsightSection(
                section_type=InsightType.DATA_QUALITY,
                title=rules['title'],
                insights=insights,
                priority='high' if completeness < 70 or consistency < 70 else 'medium'
            )
            
        except Exception as e:
            logger.error(f"Error generating data quality insights: {e}")
            return self._create_empty_section(InsightType.DATA_QUALITY, language)
    
    def _generate_distribution_insights(self, profile: Dict[str, Any], language: str) -> InsightSection:
        """Genera insights sobre las distribuciones de los datos"""
        try:
            columns = profile.get('columns', [])
            rules = self.insight_rules[language]['distributions']
            insights = []
            
            # Análisis de columnas numéricas
            numeric_columns = [col for col in columns if col.get('data_type') == 'numeric']
            
            for col in numeric_columns[:5]:  # Top 5 columnas numéricas
                stats = col.get('numeric_stats', {})
                
                if not stats:
                    continue
                
                # Detectar sesgo
                skewness = stats.get('skewness', 0)
                if abs(skewness) > 1:
                    if skewness > 0:
                        insights.append(rules['right_skewed'].format(
                            column=col['name'],
                            skewness=abs(skewness)
                        ))
                    else:
                        insights.append(rules['left_skewed'].format(
                            column=col['name'],
                            skewness=abs(skewness)
                        ))
                
                # Detectar outliers
                outlier_pct = stats.get('outlier_percentage', 0)
                if outlier_pct > 5:
                    insights.append(rules['outliers_detected'].format(
                        column=col['name'],
                        percentage=outlier_pct
                    ))
                
                # Detectar distribución normal
                if abs(skewness) < 0.5 and abs(stats.get('kurtosis', 0)) < 2:
                    insights.append(rules['normal_distribution'].format(column=col['name']))
            
            # Análisis de columnas categóricas
            categorical_columns = [col for col in columns if col.get('data_type') == 'categorical']
            
            for col in categorical_columns[:3]:  # Top 3 columnas categóricas
                stats = col.get('categorical_stats', {})
                
                if not stats:
                    continue
                
                # Detectar alta cardinalidad
                unique_pct = col.get('unique_percentage', 0)
                if unique_pct > 80:
                    insights.append(rules['high_cardinality'].format(
                        column=col['name'],
                        percentage=unique_pct
                    ))
                
                # Detectar dominancia de categorías
                top_categories = stats.get('top_categories', [])
                if top_categories and len(top_categories) > 0:
                    top_pct = top_categories[0].get('percentage', 0)
                    if top_pct > 50:
                        insights.append(rules['dominant_category'].format(
                            column=col['name'],
                            category=top_categories[0]['value'],
                            percentage=top_pct
                        ))
            
            return InsightSection(
                section_type=InsightType.DISTRIBUTIONS,
                title=rules['title'],
                insights=insights,
                priority='medium'
            )
            
        except Exception as e:
            logger.error(f"Error generating distribution insights: {e}")
            return self._create_empty_section(InsightType.DISTRIBUTIONS, language)
    
    def _generate_relationship_insights(self, profile: Dict[str, Any], language: str) -> InsightSection:
        """Genera insights sobre las relaciones entre variables"""
        try:
            correlations = profile.get('correlations', {})
            rules = self.insight_rules[language]['relationships']
            insights = []
            
            # Correlaciones fuertes
            strong_correlations = []
            for var1, corr_data in correlations.items():
                if isinstance(corr_data, dict):
                    for var2, corr_value in corr_data.items():
                        if var1 != var2 and abs(corr_value) > self.correlation_threshold:
                            strong_correlations.append((var1, var2, corr_value))
            
            # Ordenar por valor absoluto de correlación
            strong_correlations.sort(key=lambda x: abs(x[2]), reverse=True)
            
            # Top 5 correlaciones más fuertes
            for var1, var2, corr_value in strong_correlations[:5]:
                if corr_value > 0:
                    insights.append(rules['positive_correlation'].format(
                        var1=var1,
                        var2=var2,
                        correlation=abs(corr_value)
                    ))
                else:
                    insights.append(rules['negative_correlation'].format(
                        var1=var1,
                        var2=var2,
                        correlation=abs(corr_value)
                    ))
            
            # Patrones de correlación
            if len(strong_correlations) > 5:
                insights.append(rules['many_correlations'].format(
                    count=len(strong_correlations)
                ))
            
            # Correlaciones débiles
            weak_correlations = [corr for corr in strong_correlations if abs(corr[2]) < 0.3]
            if weak_correlations:
                insights.append(rules['weak_correlations'].format(
                    count=len(weak_correlations)
                ))
            
            return InsightSection(
                section_type=InsightType.RELATIONSHIPS,
                title=rules['title'],
                insights=insights,
                priority='medium'
            )
            
        except Exception as e:
            logger.error(f"Error generating relationship insights: {e}")
            return self._create_empty_section(InsightType.RELATIONSHIPS, language)
    
    def _generate_anomaly_insights(self, profile: Dict[str, Any], language: str) -> InsightSection:
        """Genera insights sobre anomalías detectadas"""
        try:
            outlier_analysis = profile.get('outlier_analysis', {})
            time_series_info = profile.get('time_series_info', {})
            rules = self.insight_rules[language]['anomalies']
            insights = []
            
            # Outliers generales
            total_outliers = outlier_analysis.get('total_outliers', 0)
            if total_outliers > 0:
                outlier_pct = (total_outliers / profile.get('summary', {}).get('total_rows', 1)) * 100
                insights.append(rules['outliers_summary'].format(
                    count=total_outliers,
                    percentage=outlier_pct
                ))
            
            # Columnas con más outliers
            outlier_columns = outlier_analysis.get('outlier_columns', [])
            if outlier_columns:
                top_outlier_col = max(outlier_columns, key=lambda x: x.get('outlier_count', 0))
                insights.append(rules['column_with_outliers'].format(
                    column=top_outlier_col['column_name'],
                    count=top_outlier_col['outlier_count']
                ))
            
            # Anomalías en series de tiempo
            if time_series_info and time_series_info.get('has_time_series'):
                anomalies = time_series_info.get('anomalies', {})
                if anomalies.get('anomalies_detected'):
                    insights.append(rules['time_series_anomalies'].format(
                        count=anomalies.get('anomaly_count', 0),
                        percentage=anomalies.get('anomaly_percentage', 0)
                    ))
                
                # Gaps en series de tiempo
                gaps = time_series_info.get('time_series_analysis', [{}])[0].get('gaps_detected', [])
                if gaps:
                    insights.append(rules['time_series_gaps'].format(
                        count=len(gaps),
                        total_days=sum(gap.get('duration_days', 0) for gap in gaps)
                    ))
            
            # Valores atípicos en distribuciones
            columns = profile.get('columns', [])
            for col in columns:
                if col.get('data_type') == 'numeric':
                    stats = col.get('numeric_stats', {})
                    if stats and stats.get('outlier_percentage', 0) > 10:
                        insights.append(rules['high_outlier_percentage'].format(
                            column=col['name'],
                            percentage=stats['outlier_percentage']
                        ))
            
            return InsightSection(
                section_type=InsightType.ANOMALIES,
                title=rules['title'],
                insights=insights,
                priority='high' if total_outliers > 0 else 'medium'
            )
            
        except Exception as e:
            logger.error(f"Error generating anomaly insights: {e}")
            return self._create_empty_section(InsightType.ANOMALIES, language)
    
    def _generate_recommendation_insights(self, profile: Dict[str, Any], language: str) -> InsightSection:
        """Genera recomendaciones basadas en el análisis"""
        try:
            summary = profile.get('summary', {})
            columns = profile.get('columns', [])
            rules = self.insight_rules[language]['recommendations']
            insights = []
            
            # Recomendaciones de limpieza
            if summary.get('completeness_score', 0) < 80:
                insights.append(rules['improve_completeness'])
            
            if summary.get('consistency_score', 0) < 80:
                insights.append(rules['improve_consistency'])
            
            # Recomendaciones de tipos de datos
            type_issues = [col for col in columns if col.get('suggestions')]
            if type_issues:
                insights.append(rules['data_type_optimization'])
            
            # Recomendaciones de outliers
            outlier_columns = [col for col in columns 
                             if col.get('data_type') == 'numeric' and 
                             col.get('numeric_stats', {}).get('outlier_percentage', 0) > 15]
            if outlier_columns:
                insights.append(rules['outlier_investigation'])
            
            # Recomendaciones de correlaciones
            correlations = profile.get('correlations', {})
            strong_corrs = sum(1 for var1, corr_data in correlations.items()
                             if isinstance(corr_data, dict) and
                             any(abs(corr_value) > 0.8 for corr_value in corr_data.values()))
            if strong_corrs > 3:
                insights.append(rules['multicollinearity_warning'])
            
            # Recomendaciones de muestreo
            if summary.get('sampling_applied'):
                insights.append(rules['sampling_consideration'])
            
            # Recomendaciones de series de tiempo
            time_series_info = profile.get('time_series_info', {})
            if time_series_info and time_series_info.get('has_time_series'):
                insights.append(rules['time_series_analysis'])
            
            return InsightSection(
                section_type=InsightType.RECOMMENDATIONS,
                title=rules['title'],
                insights=insights,
                priority='medium'
            )
            
        except Exception as e:
            logger.error(f"Error generating recommendation insights: {e}")
            return self._create_empty_section(InsightType.RECOMMENDATIONS, language)
    
    def _create_empty_section(self, section_type: InsightType, language: str) -> InsightSection:
        """Crea una sección vacía cuando hay errores"""
        empty_rules = self.insight_rules[language]['data_quality']
        return InsightSection(
            section_type=section_type,
            title=empty_rules.get('title', 'Insights'),
            insights=['No se pudieron generar insights para esta sección.'],
            priority='low'
        )
    
    # Reglas en español
    def _get_es_data_quality_rules(self) -> Dict[str, str]:
        return {
            'title': 'Calidad de Datos',
            'high_completeness': '✅ Excelente completitud de datos ({score:.1f}%). Los datos están muy completos.',
            'medium_completeness': '⚠️ Completitud moderada de datos ({score:.1f}%). Considerar completar valores faltantes.',
            'low_completeness': '❌ Baja completitud de datos ({score:.1f}%). Muchos valores faltantes que requieren atención.',
            'high_consistency': '✅ Alta consistencia de datos ({score:.1f}%). Los datos son muy consistentes.',
            'medium_consistency': '⚠️ Consistencia moderada de datos ({score:.1f}%). Algunas inconsistencias detectadas.',
            'low_consistency': '❌ Baja consistencia de datos ({score:.1f}%). Muchas inconsistencias que requieren limpieza.',
            'high_null_values': '⚠️ {count} columnas tienen más del 20% de valores nulos: {columns}.',
            'duplicates_detected': '⚠️ Se detectaron {count} filas duplicadas ({percentage:.1f}% del total).'
        }
    
    def _get_es_distribution_rules(self) -> Dict[str, str]:
        return {
            'title': 'Distribuciones',
            'right_skewed': '📈 La columna {column} tiene distribución sesgada a la derecha (skewness: {skewness:.2f}).',
            'left_skewed': '📉 La columna {column} tiene distribución sesgada a la izquierda (skewness: {skewness:.2f}).',
            'normal_distribution': '📊 La columna {column} sigue una distribución aproximadamente normal.',
            'outliers_detected': '🔍 La columna {column} tiene {percentage:.1f}% de outliers.',
            'high_cardinality': '📝 La columna {column} tiene alta cardinalidad ({percentage:.1f}% valores únicos).',
            'dominant_category': '🏆 La categoría "{category}" domina en {column} con {percentage:.1f}%.'
        }
    
    def _get_es_relationship_rules(self) -> Dict[str, str]:
        return {
            'title': 'Relaciones entre Variables',
            'positive_correlation': '📈 Correlación positiva fuerte entre {var1} y {var2} (r = {correlation:.3f}).',
            'negative_correlation': '📉 Correlación negativa fuerte entre {var1} y {var2} (r = {correlation:.3f}).',
            'many_correlations': '🔗 Se detectaron {count} correlaciones fuertes entre variables.',
            'weak_correlations': '🔍 {count} variables tienen correlaciones débiles, posiblemente independientes.'
        }
    
    def _get_es_anomaly_rules(self) -> Dict[str, str]:
        return {
            'title': 'Anomalías Detectadas',
            'outliers_summary': '🔍 Se detectaron {count} outliers ({percentage:.1f}% del total).',
            'column_with_outliers': '⚠️ La columna {column} tiene {count} outliers.',
            'time_series_anomalies': '⏰ Se detectaron {count} anomalías temporales ({percentage:.1f}% del total).',
            'time_series_gaps': '⏳ Se detectaron {count} gaps en la serie temporal, totalizando {total_days} días.',
            'high_outlier_percentage': '⚠️ La columna {column} tiene {percentage:.1f}% de outliers.'
        }
    
    def _get_es_recommendation_rules(self) -> Dict[str, str]:
        return {
            'title': 'Recomendaciones',
            'improve_completeness': '💡 Considerar estrategias para completar valores faltantes.',
            'improve_consistency': '💡 Revisar y estandarizar formatos de datos inconsistentes.',
            'data_type_optimization': '💡 Optimizar tipos de datos para mejorar rendimiento y precisión.',
            'outlier_investigation': '💡 Investigar outliers para determinar si son errores o valores válidos.',
            'multicollinearity_warning': '⚠️ Atención: posibles problemas de multicolinealidad entre variables.',
            'sampling_consideration': '💡 Los datos fueron muestreados. Considerar análisis con dataset completo.',
            'time_series_analysis': '💡 Aprovechar el análisis de series temporales para insights adicionales.'
        }
    
    # Reglas en inglés
    def _get_en_data_quality_rules(self) -> Dict[str, str]:
        return {
            'title': 'Data Quality',
            'high_completeness': '✅ Excellent data completeness ({score:.1f}%). Data is very complete.',
            'medium_completeness': '⚠️ Moderate data completeness ({score:.1f}%). Consider completing missing values.',
            'low_completeness': '❌ Low data completeness ({score:.1f}%). Many missing values require attention.',
            'high_consistency': '✅ High data consistency ({score:.1f}%). Data is very consistent.',
            'medium_consistency': '⚠️ Moderate data consistency ({score:.1f}%). Some inconsistencies detected.',
            'low_consistency': '❌ Low data consistency ({score:.1f}%). Many inconsistencies require cleaning.',
            'high_null_values': '⚠️ {count} columns have more than 20% null values: {columns}.',
            'duplicates_detected': '⚠️ {count} duplicate rows detected ({percentage:.1f}% of total).'
        }
    
    def _get_en_distribution_rules(self) -> Dict[str, str]:
        return {
            'title': 'Distributions',
            'right_skewed': '📈 Column {column} has right-skewed distribution (skewness: {skewness:.2f}).',
            'left_skewed': '📉 Column {column} has left-skewed distribution (skewness: {skewness:.2f}).',
            'normal_distribution': '📊 Column {column} follows approximately normal distribution.',
            'outliers_detected': '🔍 Column {column} has {percentage:.1f}% outliers.',
            'high_cardinality': '📝 Column {column} has high cardinality ({percentage:.1f}% unique values).',
            'dominant_category': '🏆 Category "{category}" dominates in {column} with {percentage:.1f}%.'
        }
    
    def _get_en_relationship_rules(self) -> Dict[str, str]:
        return {
            'title': 'Variable Relationships',
            'positive_correlation': '📈 Strong positive correlation between {var1} and {var2} (r = {correlation:.3f}).',
            'negative_correlation': '📉 Strong negative correlation between {var1} and {var2} (r = {correlation:.3f}).',
            'many_correlations': '🔗 {count} strong correlations detected between variables.',
            'weak_correlations': '🔍 {count} variables have weak correlations, possibly independent.'
        }
    
    def _get_en_anomaly_rules(self) -> Dict[str, str]:
        return {
            'title': 'Detected Anomalies',
            'outliers_summary': '🔍 {count} outliers detected ({percentage:.1f}% of total).',
            'column_with_outliers': '⚠️ Column {column} has {count} outliers.',
            'time_series_anomalies': '⏰ {count} temporal anomalies detected ({percentage:.1f}% of total).',
            'time_series_gaps': '⏳ {count} gaps detected in time series, totaling {total_days} days.',
            'high_outlier_percentage': '⚠️ Column {column} has {percentage:.1f}% outliers.'
        }
    
    def _get_en_recommendation_rules(self) -> Dict[str, str]:
        return {
            'title': 'Recommendations',
            'improve_completeness': '💡 Consider strategies to complete missing values.',
            'improve_consistency': '💡 Review and standardize inconsistent data formats.',
            'data_type_optimization': '💡 Optimize data types to improve performance and accuracy.',
            'outlier_investigation': '💡 Investigate outliers to determine if they are errors or valid values.',
            'multicollinearity_warning': '⚠️ Attention: possible multicollinearity issues between variables.',
            'sampling_consideration': '💡 Data was sampled. Consider analysis with complete dataset.',
            'time_series_analysis': '💡 Leverage time series analysis for additional insights.'
        }


# Instancia global del servicio
insights_service = InsightsService()
