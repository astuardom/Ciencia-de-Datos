from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from typing import Optional, Dict, Any
import os, uuid, json, shutil

from core.config import settings
from core.jobs import jobs, JobState
from core.cache import sha256_of_file, get_dataset_id_for_checksum, set_dataset_id_for_checksum

# Try to import service modules if they exist; fallback to simple stubs
try:
    from services import files as files_svc
except Exception:
    files_svc = None
try:
    from services import eda as eda_svc
except Exception:
    eda_svc = None
try:
    from services import charts as charts_svc
except Exception:
    charts_svc = None
try:
    from services import insights as insights_svc
except Exception:
    insights_svc = None
try:
    from services import report as report_svc
except Exception:
    report_svc = None
try:
    from services import clean as clean_svc
except Exception:
    clean_svc = None
try:
    from services import timeseries as ts_svc
except Exception:
    ts_svc = None

BASE_DIR = os.path.dirname(__file__)
UPLOADS = os.path.join(BASE_DIR, "uploads")
ARTIFACTS = os.path.join(BASE_DIR, "artifacts")
os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(ARTIFACTS, exist_ok=True)

app = FastAPI(title=settings.API_TITLE, version=settings.API_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def dataset_dir(dataset_id: str):
    d = os.path.join(ARTIFACTS, dataset_id)
    os.makedirs(d, exist_ok=True)
    return d

def save_json(path: str, payload: Dict[str, Any]):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

def read_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def basic_eda(df):
    # Fallback basic EDA if services.eda not present
    import pandas as pd
    summary = {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "nulls_pct_global": float(df.isna().sum().sum() / (df.shape[0]*max(df.shape[1],1)) * 100) if df.size else 0.0,
    }
    cols = []
    for c in df.columns:
        col = {
            "name": str(c),
            "dtype": str(df[c].dtype),
            "n_missing": int(df[c].isna().sum()),
            "pct_missing": float(df[c].isna().mean() * 100),
        }
        if pd.api.types.is_numeric_dtype(df[c]):
            d = df[c].describe().to_dict()
            col["describe"] = {k: (float(v) if hasattr(v, "__float__") else None) for k,v in d.items()}
        else:
            vc = df[c].astype(str).value_counts().head(10).to_dict()
            col["top_values"] = {k: int(v) for k,v in vc.items()}
        cols.append(col)
    profile = {"columns": cols}
    return summary, profile

def generate_basic_charts(df):
    import pandas as pd
    traces = []
    import numpy as np
    # histogram for up to 5 numeric columns
    numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    for c in numeric_cols[:5]:
        traces.append({"type": "histogram", "x": df[c].dropna().tolist(), "name": f"Hist {c}"})
    # bar for first categorical
    cat_cols = [c for c in df.columns if not pd.api.types.is_numeric_dtype(df[c])]
    if cat_cols:
        vc = df[cat_cols[0]].astype(str).value_counts().head(20)
        traces.append({"type": "bar", "x": vc.index.tolist(), "y": [int(v) for v in vc.values], "name": f"Top {cat_cols[0]}"})
    return {"traces": traces}

def generate_basic_insights(summary, profile):
    rows = summary.get("rows", 0)
    cols = summary.get("columns", 0)
    nulls = round(summary.get("nulls_pct_global", 0.0), 2)
    sections = [
        {"title":"Resumen ejecutivo","body":f"El dataset contiene {rows} filas y {cols} columnas. El porcentaje global de nulos es {nulls}%."},
        {"title":"Calidad de datos","body":"Revise columnas con alto porcentaje de nulos y considere imputación o eliminación."},
        {"title":"Recomendaciones","body":"Monitorear variables clave, validar tipos de datos y documentar supuestos del análisis."}
    ]
    return {"language":"es","sections":sections}

def load_df_from_upload(path: str, sheet: Optional[str]=None):
    import pandas as pd
    ext = os.path.splitext(path)[1].lower()
    if ext in [".xlsx", ".xls"]:
        # choose sheet
        try:
            xls = pd.ExcelFile(path)
            sheet_name = sheet or (xls.sheet_names[0] if xls.sheet_names else None)
            if sheet_name is None:
                raise ValueError("No sheets in Excel")
            df = pd.read_excel(xls, sheet_name=sheet_name)
        except Exception as e:
            raise
    else:
        # try csv with inference
        try:
            df = pd.read_csv(path)
        except Exception:
            df = pd.read_csv(path, sep=";", engine="python")
    return df

def process_pipeline(dataset_id: str, upload_path: str, job_id: str):
    jobs.update(job_id, state=JobState.running, progress=5, message="Cargando datos")
    # checksum + cache write
    checksum = sha256_of_file(upload_path)
    set_dataset_id_for_checksum(ARTIFACTS, checksum, dataset_id)

    # Load DF
    import pandas as pd
    df = load_df_from_upload(upload_path)
    jobs.update(job_id, progress=20, message="EDA básica")
    # EDA
    if eda_svc and hasattr(eda_svc, "compute_profile"):
        summary, profile = eda_svc.compute_profile(df)
    else:
        summary, profile = basic_eda(df)

    # Charts
    jobs.update(job_id, progress=45, message="Generando gráficos")
    if charts_svc and hasattr(charts_svc, "make_charts"):
        charts = charts_svc.make_charts(df)
    else:
        charts = generate_basic_charts(df)

    # Insights
    jobs.update(job_id, progress=65, message="Redactando insights")
    if insights_svc and hasattr(insights_svc, "write_insights"):
        insights = insights_svc.write_insights(summary, profile, df)
    else:
        insights = generate_basic_insights(summary, profile)

    # Report
    jobs.update(job_id, progress=80, message="Compilando reporte")
    artifacts_dir = os.path.join(ARTIFACTS, dataset_id)
    os.makedirs(artifacts_dir, exist_ok=True)
    # Save jsons
    save_json(os.path.join(artifacts_dir, "summary.json"), summary)
    save_json(os.path.join(artifacts_dir, "profile.json"), profile)
    save_json(os.path.join(artifacts_dir, "charts.json"), charts)
    save_json(os.path.join(artifacts_dir, "insights.json"), insights)
    # Preview
    preview = df.head(50).to_dict(orient="records")
    save_json(os.path.join(artifacts_dir, "preview.json"), {"preview":preview})

    # Report optional
    html_path = os.path.join(artifacts_dir, "report.html")
    try:
        if report_svc and hasattr(report_svc, "render_report"):
            report_svc.render_report(dataset_id, artifacts_dir)
        else:
            # basic HTML
            html = f"<html><head><meta charset='utf-8'><title>Reporte {dataset_id}</title></head><body><h1>Reporte {dataset_id}</h1><pre>{json.dumps(summary, indent=2, ensure_ascii=False)}</pre></body></html>"
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html)
    except Exception:
        pass

    jobs.update(job_id, state=JobState.done, progress=100, message="Completado")

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in [".csv", ".xlsx", ".xls"]:
        raise HTTPException(status_code=400, detail="Formato no soportado")
    # size check if possible (streamed upload length may be unknown)
    dataset_id = str(uuid.uuid4())
    upload_path = os.path.join(UPLOADS, f"{dataset_id}{ext}")
    with open(upload_path, "wb") as f:
        f.write(await file.read())

    # checksum cache
    checksum = sha256_of_file(upload_path)
    cached = get_dataset_id_for_checksum(ARTIFACTS, checksum)
    job = jobs.create(dataset_id)
    if cached:
        # fast-path: copy artifacts folder
        src = os.path.join(ARTIFACTS, cached)
        dst = os.path.join(ARTIFACTS, dataset_id)
        if os.path.isdir(src) and not os.path.exists(dst):
            shutil.copytree(src, dst)
        jobs.update(job.job_id, state=JobState.done, progress=100, message="Cache hit")
        return {"dataset_id": dataset_id, "job_id": job.job_id, "cached_from": cached}

    # background process
    from fastapi import BackgroundTasks as _BG
    bg: _BG = _BG()
    bg.add_task(process_pipeline, dataset_id, upload_path, job.job_id)
    # Trick: run background via response callback
    return JSONResponse({"dataset_id": dataset_id, "job_id": job.job_id})

@app.get("/status/{job_id}")
def status(job_id: str):
    j = jobs.get(job_id)
    if not j:
        raise HTTPException(status_code=404, detail="Job no encontrado")
    return {"state": j.state, "progress": j.progress, "message": j.message}

@app.get("/bundle/{dataset_id}")
def bundle(dataset_id: str):
    d = os.path.join(ARTIFACTS, dataset_id)
    if not os.path.isdir(d):
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    out = {}
    for name in ["summary","profile","charts","insights","preview"]:
        p = os.path.join(d, f"{name}.json")
        if os.path.exists(p):
            out[name] = read_json(p)
    # artifacts
    html = os.path.join(d, "report.html")
    pdf = os.path.join(d, "report.pdf")
    out["artifacts"] = {"html": html if os.path.exists(html) else None,
                        "pdf": pdf if os.path.exists(pdf) else None}
    return out

@app.get("/summary/{dataset_id}")
def get_summary(dataset_id: str):
    p = os.path.join(ARTIFACTS, dataset_id, "summary.json")
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail="Aún no hay summary")
    return read_json(p)

@app.get("/profile/{dataset_id}")
def get_profile(dataset_id: str):
    p = os.path.join(ARTIFACTS, dataset_id, "profile.json")
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail="Aún no hay profile")
    return read_json(p)

@app.get("/charts/{dataset_id}")
def get_charts(dataset_id: str):
    p = os.path.join(ARTIFACTS, dataset_id, "charts.json")
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail="Aún no hay charts")
    return read_json(p)

@app.get("/insights/{dataset_id}")
def get_insights(dataset_id: str):
    p = os.path.join(ARTIFACTS, dataset_id, "insights.json")
    if not os.path.exists(p):
        raise HTTPException(status_code=404, detail="Aún no hay insights")
    return read_json(p)

@app.post("/download-report")
def download_report(payload: Dict[str, Any]):
    dataset_id = payload.get("dataset_id")
    if not dataset_id:
        raise HTTPException(status_code=400, detail="dataset_id requerido")
    d = os.path.join(ARTIFACTS, dataset_id)
    if not os.path.isdir(d):
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    # rely on pre-generated report.html; pdf optional by services.report
    html = os.path.join(d, "report.html")
    pdf = os.path.join(d, "report.pdf")
    return {"html_path": html if os.path.exists(html) else None,
            "pdf_path": pdf if os.path.exists(pdf) else None}

@app.get("/download/{path:path}")
def download(path: str):
    # Serve only from artifacts
    safe_root = os.path.abspath(ARTIFACTS)
    final = os.path.abspath(os.path.join(ARTIFACTS, path))
    if not final.startswith(safe_root) or not os.path.exists(final):
        raise HTTPException(status_code=404, detail="Archivo no encontrado")
    return FileResponse(final)

@app.get("/export-clean/{dataset_id}")
def export_clean(dataset_id: str, format: str="csv"):
    d = os.path.join(ARTIFACTS, dataset_id)
    src = os.path.join(UPLOADS, f"{dataset_id}.csv")
    if not os.path.exists(src):
        # try any extension
        for ext in [".csv",".xlsx",".xls"]:
            alt = os.path.join(UPLOADS, f"{dataset_id}{ext}")
            if os.path.exists(alt):
                src = alt
                break
    if not os.path.exists(src):
        raise HTTPException(status_code=404, detail="Upload no encontrado")
    import pandas as pd
    df = None
    if src.endswith((".xlsx",".xls")):
        df = pd.read_excel(src)
    else:
        df = pd.read_csv(src)
    if clean_svc:
        from tempfile import NamedTemporaryFile
        ext = ".csv" if format=="csv" else ".parquet"
        out_path = os.path.join(d, f"clean{ext}")
        clean_svc.export_clean(df, out_path, fmt=("parquet" if format=="parquet" else "csv"))
        return FileResponse(out_path, filename=os.path.basename(out_path))
    else:
        tmp = os.path.join(d, "clean.csv")
        df.to_csv(tmp, index=False)
        return FileResponse(tmp, filename="clean.csv")

@app.delete("/dataset/{dataset_id}")
def delete_dataset(dataset_id: str):
    d = os.path.join(ARTIFACTS, dataset_id)
    u_csv = os.path.join(UPLOADS, f"{dataset_id}.csv")
    u_xlsx = os.path.join(UPLOADS, f"{dataset_id}.xlsx")
    u_xls = os.path.join(UPLOADS, f"{dataset_id}.xls")
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    for p in [u_csv, u_xlsx, u_xls]:
        if os.path.exists(p):
            os.remove(p)
    return {"deleted": dataset_id}
