# AnalizadorDatos API v2.0

API 100% autónoma en FastAPI para análisis exploratorio de datos (EDA) automático con generación de reportes, gráficos e insights.

## 🚀 Características Principales

- **EDA Autónomo**: Análisis completo automático al subir archivos Excel/CSV
- **Pipeline Asíncrono**: Procesamiento en segundo plano con seguimiento de progreso
- **Análisis Inteligente**: Detección automática de tipos de datos, correlaciones y anomalías
- **Series de Tiempo**: Inferencia automática de frecuencia y análisis temporal
- **Gráficos Interactivos**: Generación automática de visualizaciones con Plotly
- **Insights Automáticos**: Narrativa basada en reglas sin necesidad de LLM
- **Reportes Profesionales**: HTML y PDF con Jinja2 y WeasyPrint
- **Export de Datos Limpios**: CSV y Parquet con limpieza inteligente
- **Caché Inteligente**: Reutilización de resultados por checksum SHA256
- **API REST Completa**: Endpoints para todas las funcionalidades

## 🏗️ Arquitectura

```
backend/
├── app.py                 # Aplicación principal FastAPI
├── core/
│   ├── config.py         # Configuración y variables de entorno
│   ├── models.py         # Modelos Pydantic
│   ├── jobs.py           # Gestión de trabajos asíncronos
│   └── cache.py          # Sistema de caché por checksum
├── services/
│   ├── files.py          # Validación y manejo de archivos
│   ├── eda.py            # Análisis exploratorio de datos
│   ├── timeseries.py     # Análisis de series temporales
│   ├── charts.py         # Generación de gráficos Plotly
│   ├── insights.py       # Generación automática de insights
│   ├── report.py         # Generación de reportes HTML/PDF
│   └── clean.py          # Limpieza y exportación de datos
├── templates/
│   └── report.html       # Plantilla HTML para reportes
├── uploads/              # Archivos subidos
├── artifacts/            # Reportes y archivos generados
└── tests/                # Pruebas unitarias
```

## 🛠️ Stack Tecnológico

- **Backend**: FastAPI + Python 3.11
- **Procesamiento**: Pandas + Polars + NumPy + SciPy + Scikit-learn
- **Visualización**: Plotly + Matplotlib
- **Reportes**: Jinja2 + WeasyPrint
- **Caché**: Redis (opcional) + sistema en memoria
- **Validación**: Pydantic + Python-multipart
- **Archivos**: OpenPyXL + PyArrow

## 📦 Instalación

### 1. Clonar y configurar entorno

```bash
git clone <repository>
cd analyze-ease-explorer/BACKEND
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

### 2. Instalar dependencias

```bash
pip install -r requirements.txt
```

### 3. Configurar variables de entorno

```bash
cp env.example .env
# Editar .env con tus configuraciones
```

### 4. Ejecutar la aplicación

```bash
# Desarrollo
uvicorn app:app --reload --host 0.0.0.0 --port 8000

# Producción
uvicorn app:app --host 0.0.0.0 --port 8000
```

## 🔧 Configuración

### Variables de Entorno Principales

```env
# Límites de archivos
MAX_UPLOAD_MB=100
MAX_FILE_SIZE=104857600

# Caché y TTL
ARTIFACT_TTL_DAYS=30
CACHE_TTL_HOURS=24

# Funcionalidades
ENABLE_PDF=true
ENABLE_WEBSOCKET=true
ENABLE_RATE_LIMIT=true

# Límites de rate
RATE_LIMIT_PER_MINUTE=60
RATE_LIMIT_PER_HOUR=1000

# Configuración de EDA
MAX_ROWS_FOR_FULL_ANALYSIS=100000
SAMPLE_SIZE_FOR_LARGE_DATASETS=10000
OUTLIER_THRESHOLD=1.5
CORRELATION_THRESHOLD=0.5
```

## 📡 Endpoints de la API

### 1. Subida y Procesamiento

#### `POST /upload`
Sube archivo Excel/CSV y dispara análisis EDA.

**Parámetros:**
- `file`: Archivo (CSV, XLSX, XLS)
- `sheet`: Hoja específica para Excel (opcional)

**Respuesta:**
```json
{
  "dataset_id": "uuid",
  "job_id": "uuid",
  "filename": "archivo.csv",
  "file_size": 1024,
  "message": "Archivo subido exitosamente"
}
```

#### `GET /status/{job_id}`
Obtiene estado y progreso del trabajo.

**Respuesta:**
```json
{
  "job_id": "uuid",
  "dataset_id": "uuid",
  "state": "running",
  "progress": 75,
  "message": "Generando gráficos...",
  "created_at": "2024-01-01T10:00:00Z",
  "updated_at": "2024-01-01T10:05:00Z"
}
```

### 2. Análisis y Resultados

#### `GET /bundle/{dataset_id}`
Obtiene paquete completo del dataset (resumen, perfil, gráficos, insights, reportes).

#### `GET /summary/{dataset_id}`
Obtiene resumen ejecutivo con KPIs principales.

#### `GET /profile/{dataset_id}`
Obtiene perfil completo del dataset.

#### `GET /charts/{dataset_id}`
Obtiene gráficos generados en formato Plotly JSON.

#### `GET /insights/{dataset_id}`
Obtiene insights generados automáticamente.

**Parámetros:**
- `language`: Idioma (es/en)

### 3. Reportes y Exportación

#### `POST /download-report`
Genera reporte personalizado.

**Body:**
```json
{
  "dataset_id": "uuid",
  "sections": ["data_quality", "distributions", "relationships"],
  "language": "es"
}
```

#### `GET /export-clean/{dataset_id}`
Exporta datos limpios.

**Parámetros:**
- `format`: Formato de salida (csv/parquet)

#### `GET /download/{path}`
Descarga archivos de artefactos.

### 4. Gestión

#### `DELETE /dataset/{dataset_id}`
Elimina dataset y todos sus artefactos.

## 🔍 Funcionalidades del EDA

### Análisis Automático

1. **Detección de Tipos**: Identificación inteligente de tipos de datos semánticos
2. **Calidad de Datos**: Análisis de completitud, consistencia y duplicados
3. **Estadísticas Descriptivas**: Resúmenes numéricos y categóricos
4. **Correlaciones**: Matriz de correlaciones Pearson/Spearman
5. **Outliers**: Detección usando método IQR
6. **Valores Faltantes**: Patrones y análisis de missingness

### Series de Tiempo

- **Detección Automática**: Identificación de columnas de fecha/hora
- **Inferencia de Frecuencia**: D, W, M, Q, Y automático
- **Análisis de Tendencia**: Regresión lineal simple
- **Detección de Estacionalidad**: Patrones semanales, mensuales, anuales
- **Anomalías Temporales**: Gaps y valores atípicos

### Gráficos Generados

- **Distribuciones**: Histogramas, box plots, Q-Q plots
- **Categóricos**: Gráficos de barras y pie charts
- **Correlaciones**: Heatmaps y scatter plots
- **Series Temporales**: Líneas de tiempo y análisis de tendencia
- **Calidad**: Gráficos de valores faltantes y duplicados

### Insights Automáticos

- **Calidad de Datos**: Evaluación de completitud y consistencia
- **Distribuciones**: Análisis de sesgo y outliers
- **Relaciones**: Correlaciones fuertes y patrones
- **Anomalías**: Detección de valores atípicos
- **Recomendaciones**: Sugerencias de limpieza y optimización

## 📊 Ejemplo de Uso

### 1. Subir archivo y obtener análisis

```python
import requests

# Subir archivo
with open('datos.csv', 'rb') as f:
    response = requests.post('http://localhost:8000/upload', 
                           files={'file': f})
    
data = response.json()
dataset_id = data['dataset_id']
job_id = data['job_id']

# Monitorear progreso
while True:
    status = requests.get(f'http://localhost:8000/status/{job_id}').json()
    if status['state'] == 'done':
        break
    time.sleep(5)

# Obtener resultados completos
bundle = requests.get(f'http://localhost:8000/bundle/{dataset_id}').json()
print(f"Análisis completado: {bundle['summary']['total_rows']} filas")
```

### 2. Generar reporte personalizado

```python
report_request = {
    "dataset_id": dataset_id,
    "sections": ["data_quality", "distributions"],
    "language": "es"
}

report = requests.post('http://localhost:8000/download-report', 
                      json=report_request).json()

print(f"Reporte HTML: {report['html_url']}")
if report.get('pdf_url'):
    print(f"Reporte PDF: {report['pdf_url']}")
```

### 3. Exportar datos limpios

```python
# CSV
csv_export = requests.get(f'http://localhost:8000/export-clean/{dataset_id}?format=csv').json()

# Parquet
parquet_export = requests.get(f'http://localhost:8000/export-clean/{dataset_id}?format=parquet').json()
```

## 🧪 Pruebas

### Ejecutar pruebas automáticas

```bash
python test_api.py
```

### Pruebas unitarias

```bash
pytest tests/ -v
```

## 🚀 Despliegue

### Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Docker Compose

```yaml
version: '3.8'
services:
  api:
    build: .
    ports:
      - "8000:8000"
    volumes:
      - ./uploads:/app/uploads
      - ./artifacts:/app/artifacts
    environment:
      - MAX_UPLOAD_MB=100
      - ENABLE_PDF=true
```

## 📈 Rendimiento

- **Objetivo**: <30s para datasets de 50k filas
- **Muestreo Inteligente**: Aplicado automáticamente para datasets grandes
- **Caché**: Evita reprocesamiento de archivos idénticos
- **Procesamiento Paralelo**: Análisis concurrente de diferentes aspectos

## 🔒 Seguridad

- **Validación de Archivos**: Verificación de MIME types y extensiones
- **Límites de Tamaño**: Configurables por variable de entorno
- **Rate Limiting**: Protección contra abuso
- **CORS**: Configurable para orígenes permitidos
- **Sanitización**: Limpieza de nombres de archivos y columnas

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver `LICENSE` para más detalles.

## 🆘 Soporte

- **Issues**: Reporta bugs y solicita features en GitHub
- **Documentación**: Consulta la documentación de la API en `/docs`
- **Comunidad**: Únete a nuestro canal de Discord

---

**AnalizadorDatos API v2.0** - Transformando el análisis de datos en una experiencia autónoma y poderosa. 🚀
