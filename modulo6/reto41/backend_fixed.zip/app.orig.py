import asyncio
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import uvicorn

from core.config import settings
from core.models import (
    UploadRequest, UploadResponse, JobStatus, DatasetSummary, 
    DatasetProfile, BundleResponse, ExportRequest, ReportRequest,
    ReportResponse, ErrorResponse, SuccessResponse, Language
)
from core.jobs import job_manager, JobType, JobPriority
from core.cache import cache_manager
from services.files import file_service
from services.eda import eda_service
from services.timeseries import time_series_service
from services.charts import charts_service
from services.insights import insights_service
from services.report import report_service
from services.clean import clean_data_service

# Configurar logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configurar rate limiting
limiter = Limiter(key_func=get_remote_address)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gestión del ciclo de vida de la aplicación"""
    # Iniciar servicios
    logger.info("Starting application services...")
    await job_manager.start()
    
    yield
    
    # Detener servicios
    logger.info("Stopping application services...")
    await job_manager.stop()

# Crear aplicación FastAPI
app = FastAPI(
    title="AnalizadorDatos API",
    description="API autónoma para análisis exploratorio de datos con EDA automático",
    version="2.0.0",
    lifespan=lifespan
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar rate limiting
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Montar archivos estáticos
app.mount("/artifacts", StaticFiles(directory=settings.artifacts_dir), name="artifacts")

@app.get("/")
async def root():
    """Endpoint raíz con información de la API"""
    return {
        "message": "AnalizadorDatos API v2.0",
        "description": "API autónoma para análisis exploratorio de datos",
        "version": "2.0.0",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Verificación de salud de la API"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "services": {
            "job_manager": "running",
            "cache_manager": "running",
            "file_service": "running"
        }
    }

@app.post("/upload", response_model=UploadResponse)
@limiter.limit(f"{settings.RATE_LIMIT_PER_MINUTE}/minute")
async def upload_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    sheet: str = Form(None)
):
    """
    Sube un archivo Excel o CSV y dispara el análisis EDA
    
    Args:
        file: Archivo a subir (CSV, XLSX, XLS)
        sheet: Nombre de la hoja para archivos Excel (opcional)
    
    Returns:
        Información del dataset y trabajo creado
    """
    try:
        # Validar archivo
        is_valid, error_message, file_type = file_service.validate_file(file)
        if not is_valid:
            raise HTTPException(status_code=400, detail=error_message)
        
        # Generar IDs únicos
        dataset_id = generate_dataset_id()
        job_id = generate_job_id()
        
        # Guardar archivo
        file_path = file_service.save_file(file, dataset_id)
        
        # Crear trabajo de análisis
        background_tasks.add_task(
            process_upload_job,
            dataset_id=dataset_id,
            job_id=job_id,
            file_path=file_path,
            sheet_name=sheet
        )
        
        # Obtener información del archivo
        file_info = file_service.get_file_info(file_path)
        
        return UploadResponse(
            dataset_id=dataset_id,
            job_id=job_id,
            filename=file.filename,
            file_size=file.size,
            message="Archivo subido exitosamente. El análisis comenzará en breve."
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in upload: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

async def process_upload_job(dataset_id: str, job_id: str, file_path: Path, sheet_name: str = None):
    """Procesa el trabajo de subida en segundo plano"""
    try:
        # Crear trabajo
        job = await job_manager.submit_job(
            dataset_id=dataset_id,
            job_type=JobType.UPLOAD,
            priority=JobPriority.NORMAL,
            metadata={
                'file_path': str(file_path),
                'sheet_name': sheet_name
            },
            work_function=lambda j: _process_upload_work(j, file_path, sheet_name)
        )
        
        logger.info(f"Upload job {job_id} submitted for dataset {dataset_id}")
        
    except Exception as e:
        logger.error(f"Error submitting upload job: {e}")

def _process_upload_work(job, file_path: Path, sheet_name: str = None):
    """Función de trabajo para procesar la subida"""
    try:
        job.update_progress(10, "Leyendo archivo...")
        
        # Leer archivo
        df = file_service.read_file(file_path, sheet_name)
        
        job.update_progress(20, "Iniciando análisis EDA...")
        
        # Realizar análisis EDA
        profile = eda_service.analyze_dataset(df, job.dataset_id, file_path)
        
        job.update_progress(40, "Analizando series de tiempo...")
        
        # Análisis de series de tiempo
        time_series_info = time_series_service.analyze_time_series(df)
        if time_series_info:
            profile['time_series_info'] = time_series_info
        
        job.update_progress(60, "Generando gráficos...")
        
        # Generar gráficos
        charts = charts_service.generate_charts(df, profile, time_series_info)
        profile['charts'] = charts
        
        job.update_progress(80, "Generando insights...")
        
        # Generar insights
        insights = insights_service.generate_insights(profile, Language.ES)
        profile['insights'] = insights
        
        job.update_progress(90, "Generando reportes...")
        
        # Generar reportes
        report_info = report_service.generate_report(job.dataset_id, profile, insights, Language.ES)
        profile['report_info'] = report_info
        
        job.update_progress(100, "Análisis completado exitosamente")
        
        return {
            'dataset_id': job.dataset_id,
            'profile': profile,
            'file_path': str(file_path),
            'charts': charts,
            'insights': insights,
            'report_info': report_info
        }
        
    except Exception as e:
        logger.error(f"Error in upload work: {e}")
        raise

@app.get("/status/{job_id}", response_model=JobStatus)
async def get_job_status(job_id: str):
    """Obtiene el estado de un trabajo"""
    try:
        job = await job_manager.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Trabajo no encontrado")
        
        return job.to_status_model()
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting job status: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/bundle/{dataset_id}", response_model=BundleResponse)
async def get_dataset_bundle(dataset_id: str):
    """Obtiene el paquete completo del dataset"""
    try:
        # Obtener perfil del dataset
        profile = cache_manager.get_dataset_profile(dataset_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Dataset no encontrado")
        
        # Generar insights si no existen
        if 'insights' not in profile:
            insights = insights_service.generate_insights(profile, Language.ES)
            profile['insights'] = insights
        
        # Generar gráficos si no existen
        if 'charts' not in profile:
            df = file_service.load_dataset(dataset_id)
            charts = charts_service.generate_charts(df, profile, profile.get('time_series_info'))
            profile['charts'] = charts
        
        # Generar reporte si no existe
        if 'report_info' not in profile:
            report_info = report_service.generate_report(dataset_id, profile, profile['insights'], Language.ES)
            profile['report_info'] = report_info
        
        return BundleResponse(
            dataset_id=dataset_id,
            summary=profile.get('summary', {}),
            profile=profile,
            charts=profile.get('charts', []),
            insights=profile.get('insights', []),
            artifacts=profile.get('report_info', {}),
            sample_preview=profile.get('sample_data', [])
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset bundle: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/summary/{dataset_id}", response_model=DatasetSummary)
async def get_dataset_summary(dataset_id: str):
    """Obtiene el resumen del dataset"""
    try:
        profile = cache_manager.get_dataset_profile(dataset_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Dataset no encontrado")
        
        return profile.get('summary', {})
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset summary: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/profile/{dataset_id}")
async def get_dataset_profile(dataset_id: str):
    """Obtiene el perfil completo del dataset"""
    try:
        profile = cache_manager.get_dataset_profile(dataset_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Dataset no encontrado")
        
        return profile
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset profile: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/charts/{dataset_id}")
async def get_dataset_charts(dataset_id: str):
    """Obtiene los gráficos del dataset"""
    try:
        profile = cache_manager.get_dataset_profile(dataset_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Dataset no encontrado")
        
        if 'charts' not in profile:
            df = file_service.load_dataset(dataset_id)
            charts = charts_service.generate_charts(df, profile, profile.get('time_series_info'))
            profile['charts'] = charts
        
        return {"charts": profile.get('charts', [])}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset charts: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/insights/{dataset_id}")
async def get_dataset_insights(dataset_id: str, language: str = "es"):
    """Obtiene los insights del dataset"""
    try:
        profile = cache_manager.get_dataset_profile(dataset_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Dataset no encontrado")
        
        lang = Language(language) if language in ['es', 'en'] else Language.ES
        
        if 'insights' not in profile:
            insights = insights_service.generate_insights(profile, lang)
            profile['insights'] = insights
        
        return {"insights": profile.get('insights', [])}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset insights: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.post("/download-report")
async def download_report(request: ReportRequest):
    """Descarga reporte personalizado"""
    try:
        profile = cache_manager.get_dataset_profile(request.dataset_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Dataset no encontrado")
        
        lang = request.language if request.language else Language.ES
        
        # Generar insights si no existen
        if 'insights' not in profile:
            insights = insights_service.generate_insights(profile, lang)
        else:
            insights = profile['insights']
        
        # Generar reporte
        report_info = report_service.generate_custom_report(
            request.dataset_id, 
            profile, 
            request.sections, 
            lang
        )
        
        return ReportResponse(
            dataset_id=request.dataset_id,
            html_path=report_info.get('html_path'),
            pdf_path=report_info.get('pdf_path'),
            html_url=report_info.get('html_url'),
            pdf_url=report_info.get('pdf_url')
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading report: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/export-clean/{dataset_id}")
async def export_clean_data(dataset_id: str, format: str = "csv"):
    """Exporta datos limpios del dataset"""
    try:
        profile = cache_manager.get_dataset_profile(dataset_id)
        if not profile:
            raise HTTPException(status_code=404, detail="Dataset no encontrado")
        
        df = file_service.load_dataset(dataset_id)
        
        # Validar formato
        if format.lower() not in ['csv', 'parquet']:
            raise HTTPException(status_code=400, detail="Formato no soportado. Use 'csv' o 'parquet'")
        
        # Exportar datos limpios
        export_info = clean_data_service.export_clean_data(df, dataset_id, format, profile)
        
        return export_info
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error exporting clean data: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.delete("/dataset/{dataset_id}")
async def delete_dataset(dataset_id: str):
    """Elimina un dataset y todos sus artefactos"""
    try:
        # Eliminar archivos
        file_service.delete_dataset_files(dataset_id)
        
        # Eliminar artefactos
        artifacts_dir = settings.artifacts_dir / dataset_id
        if artifacts_dir.exists():
            import shutil
            shutil.rmtree(artifacts_dir)
        
        # Limpiar caché
        cache_manager.clear_dataset_cache(dataset_id)
        
        return {"message": f"Dataset {dataset_id} eliminado exitosamente"}
        
    except Exception as e:
        logger.error(f"Error deleting dataset: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/download/{path:path}")
async def download_file(path: str):
    """Sirve archivos de artefactos de forma segura"""
    try:
        file_path = settings.artifacts_dir / path
        if not file_path.exists() or not file_path.is_file():
            raise HTTPException(status_code=404, detail="Archivo no encontrado")
        
        # Validar que el archivo esté dentro del directorio de artefactos
        try:
            file_path.relative_to(settings.artifacts_dir)
        except ValueError:
            raise HTTPException(status_code=403, detail="Acceso denegado")
        
        return FileResponse(file_path)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")
async def get_job_status(job_id: str):
    """
    Obtiene el estado de un trabajo
    
    Args:
        job_id: ID del trabajo
    
    Returns:
        Estado actual del trabajo
    """
    try:
        status = job_manager.get_job_status(job_id)
        if not status:
            raise HTTPException(status_code=404, detail="Trabajo no encontrado")
        
        return status
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting job status: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/summary/{dataset_id}", response_model=DatasetSummary)
async def get_dataset_summary(dataset_id: str):
    """
    Obtiene el resumen de un dataset
    
    Args:
        dataset_id: ID del dataset
    
    Returns:
        Resumen del dataset
    """
    try:
        # TODO: Implementar obtención del resumen desde almacenamiento
        raise HTTPException(status_code=501, detail="Endpoint no implementado aún")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset summary: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/profile/{dataset_id}", response_model=DatasetProfile)
async def get_dataset_profile(dataset_id: str):
    """
    Obtiene el perfil completo de un dataset
    
    Args:
        dataset_id: ID del dataset
    
    Returns:
        Perfil completo del dataset
    """
    try:
        # TODO: Implementar obtención del perfil desde almacenamiento
        raise HTTPException(status_code=501, detail="Endpoint no implementado aún")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset profile: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/bundle/{dataset_id}", response_model=BundleResponse)
async def get_dataset_bundle(dataset_id: str):
    """
    Obtiene el bundle completo de un dataset
    
    Args:
        dataset_id: ID del dataset
    
    Returns:
        Bundle completo con todos los análisis
    """
    try:
        # TODO: Implementar obtención del bundle desde almacenamiento
        raise HTTPException(status_code=501, detail="Endpoint no implementado aún")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset bundle: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.post("/download-report", response_model=ReportResponse)
async def generate_report(request: ReportRequest):
    """
    Genera un reporte en HTML/PDF
    
    Args:
        request: Parámetros del reporte
    
    Returns:
        Información del reporte generado
    """
    try:
        # TODO: Implementar generación de reportes
        raise HTTPException(status_code=501, detail="Endpoint no implementado aún")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating report: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/download/{path:path}")
async def download_file(path: str):
    """
    Descarga un archivo desde el directorio de artefactos
    
    Args:
        path: Ruta relativa al archivo
    
    Returns:
        Archivo solicitado
    """
    try:
        file_path = settings.artifacts_dir / path
        
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="Archivo no encontrado")
        
        if not file_path.is_file():
            raise HTTPException(status_code=400, detail="La ruta no es un archivo válido")
        
        return FileResponse(file_path)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/export-clean/{dataset_id}")
async def export_clean_data(dataset_id: str, format: str = "csv"):
    """
    Exporta datos limpios del dataset
    
    Args:
        dataset_id: ID del dataset
        format: Formato de exportación (csv, parquet)
    
    Returns:
        Archivo de datos limpios
    """
    try:
        # TODO: Implementar exportación de datos limpios
        raise HTTPException(status_code=501, detail="Endpoint no implementado aún")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error exporting clean data: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.delete("/dataset/{dataset_id}")
async def delete_dataset(dataset_id: str):
    """
    Elimina un dataset completo
    
    Args:
        dataset_id: ID del dataset
    
    Returns:
        Confirmación de eliminación
    """
    try:
        # Eliminar archivos
        files_deleted = file_service.delete_dataset_files(dataset_id)
        
        # TODO: Eliminar artefactos y caché
        
        if files_deleted:
            return SuccessResponse(
                message=f"Dataset {dataset_id} eliminado exitosamente",
                data={"dataset_id": dataset_id, "files_deleted": True}
            )
        else:
            return SuccessResponse(
                message=f"Dataset {dataset_id} no encontrado o ya eliminado",
                data={"dataset_id": dataset_id, "files_deleted": False}
            )
        
    except Exception as e:
        logger.error(f"Error deleting dataset: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/stats")
async def get_system_stats():
    """Obtiene estadísticas del sistema"""
    try:
        job_stats = job_manager.get_stats()
        cache_stats = cache_manager.get_cache_stats()
        
        return {
            "job_manager": job_stats,
            "cache_manager": cache_stats,
            "system": {
                "timestamp": datetime.now().isoformat(),
                "version": "2.0.0"
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting system stats: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

@app.get("/cache/clear")
async def clear_cache():
    """Limpia todo el caché del sistema"""
    try:
        deleted_count = cache_manager.clear_all_cache()
        
        return SuccessResponse(
            message=f"Caché limpiado exitosamente",
            data={"deleted_files": deleted_count}
        )
        
    except Exception as e:
        logger.error(f"Error clearing cache: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

# Manejo de errores global
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Manejador global de excepciones"""
    logger.error(f"Unhandled exception: {exc}")
    return JSONResponse(
        status_code=500,
        content=ErrorResponse(
            error="Internal Server Error",
            message="Ocurrió un error interno del servidor",
            details={"exception": str(exc)}
        ).dict()
    )

if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )
