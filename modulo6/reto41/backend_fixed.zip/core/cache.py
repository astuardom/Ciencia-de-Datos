import hashlib
import json
import pickle
from typing import Any, Dict, Optional, Union
from pathlib import Path
from datetime import datetime, timedelta
import os
from core.config import settings
import logging

logger = logging.getLogger(__name__)


class CacheManager:
    """Gestor de caché basado en checksum SHA256 de archivos"""
    
    def __init__(self):
        self.cache_dir = settings.artifacts_dir / "cache"
        self.cache_dir.mkdir(exist_ok=True)
        self.metadata_file = self.cache_dir / "cache_metadata.json"
        self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict[str, Any]:
        """Carga los metadatos del caché"""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading cache metadata: {e}")
                return {}
        return {}
    
    def _save_metadata(self):
        """Guarda los metadatos del caché"""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Error saving cache metadata: {e}")
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calcula el checksum SHA256 de un archivo"""
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(chunk)
            return sha256_hash.hexdigest()
        except Exception as e:
            logger.error(f"Error calculating checksum for {file_path}: {e}")
            return ""
    
    def _get_cache_key(self, checksum: str, analysis_type: str) -> str:
        """Genera una clave de caché única"""
        return f"{checksum}_{analysis_type}"
    
    def _get_cache_path(self, cache_key: str) -> Path:
        """Obtiene la ruta del archivo de caché"""
        return self.cache_dir / f"{cache_key}.pkl"
    
    def _is_cache_valid(self, cache_key: str) -> bool:
        """Verifica si el caché es válido (no expirado)"""
        if cache_key not in self.metadata:
            return False
        
        cache_info = self.metadata[cache_key]
        created_at = datetime.fromisoformat(cache_info['created_at'])
        ttl_hours = settings.CACHE_TTL_HOURS
        
        return datetime.now() - created_at < timedelta(hours=ttl_hours)
    
    def get_cached_result(self, file_path: Path, analysis_type: str) -> Optional[Any]:
        """
        Obtiene un resultado del caché si existe y es válido
        
        Args:
            file_path: Ruta al archivo original
            analysis_type: Tipo de análisis (profile, charts, insights, etc.)
        
        Returns:
            Resultado cacheado o None si no existe o expiró
        """
        try:
            checksum = self._calculate_checksum(file_path)
            if not checksum:
                return None
            
            cache_key = self._get_cache_key(checksum, analysis_type)
            cache_path = self._get_cache_path(cache_key)
            
            # Verificar si existe en caché y es válido
            if not cache_path.exists() or not self._is_cache_valid(cache_key):
                return None
            
            # Cargar resultado del caché
            with open(cache_path, 'rb') as f:
                result = pickle.load(f)
            
            logger.info(f"Cache hit for {analysis_type} with checksum {checksum[:8]}...")
            return result
            
        except Exception as e:
            logger.error(f"Error retrieving from cache: {e}")
            return None
    
    def cache_result(self, file_path: Path, analysis_type: str, result: Any) -> bool:
        """
        Guarda un resultado en el caché
        
        Args:
            file_path: Ruta al archivo original
            analysis_type: Tipo de análisis
            result: Resultado a cachear
        
        Returns:
            True si se guardó exitosamente, False en caso contrario
        """
        try:
            checksum = self._calculate_checksum(file_path)
            if not checksum:
                return False
            
            cache_key = self._get_cache_key(checksum, analysis_type)
            cache_path = self._get_cache_path(cache_key)
            
            # Guardar resultado en caché
            with open(cache_path, 'wb') as f:
                pickle.dump(result, f)
            
            # Actualizar metadatos
            self.metadata[cache_key] = {
                'checksum': checksum,
                'analysis_type': analysis_type,
                'file_path': str(file_path),
                'created_at': datetime.now().isoformat(),
                'result_size_bytes': os.path.getsize(cache_path)
            }
            
            self._save_metadata()
            
            logger.info(f"Cached result for {analysis_type} with checksum {checksum[:8]}...")
            return True
            
        except Exception as e:
            logger.error(f"Error caching result: {e}")
            return False
    
    def get_cache_info(self, file_path: Path) -> Dict[str, Any]:
        """
        Obtiene información sobre el caché de un archivo
        
        Args:
            file_path: Ruta al archivo
        
        Returns:
            Información del caché
        """
        try:
            checksum = self._calculate_checksum(file_path)
            if not checksum:
                return {}
            
            cache_info = {}
            for analysis_type in ['profile', 'charts', 'insights', 'summary']:
                cache_key = self._get_cache_key(checksum, analysis_type)
                if cache_key in self.metadata:
                    cache_info[analysis_type] = {
                        'exists': True,
                        'created_at': self.metadata[cache_key]['created_at'],
                        'size_bytes': self.metadata[cache_key]['result_size_bytes'],
                        'is_valid': self._is_cache_valid(cache_key)
                    }
                else:
                    cache_info[analysis_type] = {
                        'exists': False,
                        'created_at': None,
                        'size_bytes': 0,
                        'is_valid': False
                    }
            
            return {
                'checksum': checksum,
                'cache_info': cache_info
            }
            
        except Exception as e:
            logger.error(f"Error getting cache info: {e}")
            return {}
    
    def clear_expired_cache(self) -> int:
        """
        Limpia el caché expirado
        
        Returns:
            Número de archivos eliminados
        """
        try:
            deleted_count = 0
            current_time = datetime.now()
            ttl_hours = settings.CACHE_TTL_HOURS
            
            expired_keys = []
            
            for cache_key, cache_info in self.metadata.items():
                created_at = datetime.fromisoformat(cache_info['created_at'])
                if current_time - created_at >= timedelta(hours=ttl_hours):
                    expired_keys.append(cache_key)
            
            for cache_key in expired_keys:
                cache_path = self._get_cache_path(cache_key)
                if cache_path.exists():
                    cache_path.unlink()
                    deleted_count += 1
                
                del self.metadata[cache_key]
            
            if expired_keys:
                self._save_metadata()
                logger.info(f"Cleared {deleted_count} expired cache entries")
            
            return deleted_count
            
        except Exception as e:
            logger.error(f"Error clearing expired cache: {e}")
            return 0
    
    def clear_all_cache(self) -> int:
        """
        Limpia todo el caché
        
        Returns:
            Número de archivos eliminados
        """
        try:
            deleted_count = 0
            
            # Eliminar archivos de caché
            for cache_file in self.cache_dir.glob("*.pkl"):
                cache_file.unlink()
                deleted_count += 1
            
            # Limpiar metadatos
            self.metadata.clear()
            self._save_metadata()
            
            logger.info(f"Cleared all cache: {deleted_count} files")
            return deleted_count
            
        except Exception as e:
            logger.error(f"Error clearing all cache: {e}")
            return 0
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Obtiene estadísticas del caché
        
        Returns:
            Estadísticas del caché
        """
        try:
            total_size = 0
            valid_entries = 0
            expired_entries = 0
            
            current_time = datetime.now()
            ttl_hours = settings.CACHE_TTL_HOURS
            
            for cache_key, cache_info in self.metadata.items():
                total_size += cache_info.get('result_size_bytes', 0)
                created_at = datetime.fromisoformat(cache_info['created_at'])
                
                if current_time - created_at < timedelta(hours=ttl_hours):
                    valid_entries += 1
                else:
                    expired_entries += 1
            
            return {
                'total_entries': len(self.metadata),
                'valid_entries': valid_entries,
                'expired_entries': expired_entries,
                'total_size_bytes': total_size,
                'total_size_mb': round(total_size / (1024 * 1024), 2),
                'cache_dir': str(self.cache_dir)
            }
            
        except Exception as e:
            logger.error(f"Error getting cache stats: {e}")
            return {}


# Instancia global del gestor de caché
cache_manager = CacheManager()
