import asyncio
import threading
from typing import Dict, Any, Optional, Callable, List
from datetime import datetime, timedelta
from enum import Enum
import uuid
import logging
from concurrent.futures import ThreadPoolExecutor
from core.models import JobState, JobStatus
from core.config import settings

logger = logging.getLogger(__name__)


class JobPriority(str, Enum):
    """Prioridades de trabajo"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


class JobType(str, Enum):
    """Tipos de trabajo"""
    UPLOAD = "upload"
    PROFILE = "profile"
    CHARTS = "charts"
    INSIGHTS = "insights"
    REPORT = "report"
    EXPORT = "export"
    BUNDLE = "bundle"


class Job:
    """Representa un trabajo individual"""
    
    def __init__(
        self,
        job_id: str,
        dataset_id: str,
        job_type: JobType,
        priority: JobPriority = JobPriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.job_id = job_id
        self.dataset_id = dataset_id
        self.job_type = job_type
        self.priority = priority
        self.metadata = metadata or {}
        
        # Estado del trabajo
        self.state = JobState.QUEUED
        self.progress = 0
        self.message = "Trabajo en cola"
        self.error_details = None
        
        # Timestamps
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.started_at = None
        self.completed_at = None
        
        # Estimaciones
        self.estimated_duration = None
        self.estimated_completion = None
        
        # Resultado
        self.result = None
        
        # Callbacks
        self.progress_callback = None
        self.completion_callback = None
        self.error_callback = None
    
    def update_progress(self, progress: int, message: str):
        """Actualiza el progreso del trabajo"""
        self.progress = max(0, min(100, progress))
        self.message = message
        self.updated_at = datetime.now()
        
        if self.progress_callback:
            try:
                self.progress_callback(self)
            except Exception as e:
                logger.error(f"Error in progress callback: {e}")
    
    def start(self):
        """Marca el trabajo como iniciado"""
        self.state = JobState.RUNNING
        self.started_at = datetime.now()
        self.message = "Trabajo en ejecución"
        self.updated_at = datetime.now()
        
        # Calcular estimación de duración basada en el tipo de trabajo
        self._calculate_estimated_duration()
    
    def complete(self, result: Any = None):
        """Marca el trabajo como completado"""
        self.state = JobState.DONE
        self.progress = 100
        self.message = "Trabajo completado exitosamente"
        self.completed_at = datetime.now()
        self.updated_at = datetime.now()
        self.result = result
        
        if self.completion_callback:
            try:
                self.completion_callback(self)
            except Exception as e:
                logger.error(f"Error in completion callback: {e}")
    
    def fail(self, error_details: str):
        """Marca el trabajo como fallido"""
        self.state = JobState.ERROR
        self.message = "Trabajo falló"
        self.error_details = error_details
        self.completed_at = datetime.now()
        self.updated_at = datetime.now()
        
        if self.error_callback:
            try:
                self.error_callback(self)
            except Exception as e:
                logger.error(f"Error in error callback: {e}")
    
    def _calculate_estimated_duration(self):
        """Calcula la duración estimada basada en el tipo de trabajo"""
        base_durations = {
            JobType.UPLOAD: 30,      # 30 segundos
            JobType.PROFILE: 120,    # 2 minutos
            JobType.CHARTS: 180,     # 3 minutos
            JobType.INSIGHTS: 90,    # 1.5 minutos
            JobType.REPORT: 300,     # 5 minutos
            JobType.EXPORT: 60,      # 1 minuto
            JobType.BUNDLE: 600,     # 10 minutos
        }
        
        base_duration = base_durations.get(self.job_type, 120)
        
        # Ajustar por prioridad
        priority_multipliers = {
            JobPriority.LOW: 1.5,
            JobPriority.NORMAL: 1.0,
            JobPriority.HIGH: 0.7,
            JobPriority.URGENT: 0.5,
        }
        
        multiplier = priority_multipliers.get(self.priority, 1.0)
        self.estimated_duration = timedelta(seconds=int(base_duration * multiplier))
        
        if self.started_at:
            self.estimated_completion = self.started_at + self.estimated_duration
    
    def to_status(self) -> JobStatus:
        """Convierte el trabajo a un modelo de estado"""
        return JobStatus(
            job_id=self.job_id,
            dataset_id=self.dataset_id,
            state=self.state,
            progress=self.progress,
            message=self.message,
            created_at=self.created_at,
            updated_at=self.updated_at,
            estimated_completion=self.estimated_completion,
            error_details=self.error_details
        )
    
    def get_elapsed_time(self) -> timedelta:
        """Obtiene el tiempo transcurrido desde la creación"""
        return datetime.now() - self.created_at
    
    def get_remaining_time(self) -> Optional[timedelta]:
        """Obtiene el tiempo restante estimado"""
        if self.estimated_completion and self.state == JobState.RUNNING:
            remaining = self.estimated_completion - datetime.now()
            return max(timedelta(0), remaining)
        return None


class JobManager:
    """Gestor de trabajos asíncronos"""
    
    def __init__(self, max_workers: int = 4):
        self.jobs: Dict[str, Job] = {}
        self.job_queue = asyncio.Queue()
        self.max_workers = max_workers
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.running = False
        self.workers = []
        
        # Estadísticas
        self.stats = {
            'total_jobs': 0,
            'completed_jobs': 0,
            'failed_jobs': 0,
            'queued_jobs': 0,
            'running_jobs': 0,
        }
    
    async def start(self):
        """Inicia el gestor de trabajos"""
        if self.running:
            return
        
        self.running = True
        logger.info(f"Starting JobManager with {self.max_workers} workers")
        
        # Crear workers
        for i in range(self.max_workers):
            worker = asyncio.create_task(self._worker(f"worker-{i}"))
            self.workers.append(worker)
    
    async def stop(self):
        """Detiene el gestor de trabajos"""
        if not self.running:
            return
        
        self.running = False
        logger.info("Stopping JobManager")
        
        # Cancelar workers
        for worker in self.workers:
            worker.cancel()
        
        # Esperar a que terminen
        await asyncio.gather(*self.workers, return_exceptions=True)
        
        # Cerrar executor
        self.executor.shutdown(wait=True)
        
        logger.info("JobManager stopped")
    
    async def submit_job(
        self,
        dataset_id: str,
        job_type: JobType,
        priority: JobPriority = JobPriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
        work_function: Optional[Callable] = None
    ) -> str:
        """
        Envía un trabajo para ser procesado
        
        Args:
            dataset_id: ID del dataset
            job_type: Tipo de trabajo
            priority: Prioridad del trabajo
            metadata: Metadatos adicionales
            work_function: Función de trabajo a ejecutar
        
        Returns:
            ID del trabajo creado
        """
        job_id = f"job_{uuid.uuid4().hex[:8]}"
        
        job = Job(
            job_id=job_id,
            dataset_id=dataset_id,
            job_type=job_type,
            priority=priority,
            metadata=metadata
        )
        
        # Configurar callbacks si se proporciona una función de trabajo
        if work_function:
            job.progress_callback = lambda j: self._on_job_progress(j)
            job.completion_callback = lambda j: self._on_job_completion(j)
            job.error_callback = lambda j: self._on_job_error(j)
            
            # Agregar la función de trabajo a los metadatos
            job.metadata['work_function'] = work_function
        
        # Registrar el trabajo
        self.jobs[job_id] = job
        self.stats['total_jobs'] += 1
        self.stats['queued_jobs'] += 1
        
        # Enviar a la cola
        await self.job_queue.put((priority, job))
        
        logger.info(f"Submitted job {job_id} of type {job_type} for dataset {dataset_id}")
        return job_id
    
    async def _worker(self, worker_name: str):
        """Worker que procesa trabajos de la cola"""
        logger.info(f"Worker {worker_name} started")
        
        while self.running:
            try:
                # Obtener trabajo de la cola
                priority, job = await asyncio.wait_for(
                    self.job_queue.get(), timeout=1.0
                )
                
                logger.info(f"Worker {worker_name} processing job {job.job_id}")
                
                # Procesar el trabajo
                await self._process_job(job)
                
                # Marcar como completado
                self.job_queue.task_done()
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Worker {worker_name} error: {e}")
                continue
        
        logger.info(f"Worker {worker_name} stopped")
    
    async def _process_job(self, job: Job):
        """Procesa un trabajo individual"""
        try:
            # Marcar como iniciado
            job.start()
            self.stats['queued_jobs'] -= 1
            self.stats['running_jobs'] += 1
            
            # Ejecutar la función de trabajo si existe
            if 'work_function' in job.metadata:
                work_function = job.metadata['work_function']
                
                # Ejecutar en thread pool para operaciones bloqueantes
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    self.executor, 
                    work_function, 
                    job
                )
                
                job.complete(result)
            else:
                # Trabajo sin función de trabajo (solo para seguimiento)
                job.complete()
            
            self.stats['running_jobs'] -= 1
            self.stats['completed_jobs'] += 1
            
        except Exception as e:
            logger.error(f"Error processing job {job.job_id}: {e}")
            job.fail(str(e))
            self.stats['running_jobs'] -= 1
            self.stats['failed_jobs'] += 1
    
    def _on_job_progress(self, job: Job):
        """Callback cuando se actualiza el progreso de un trabajo"""
        logger.debug(f"Job {job.job_id} progress: {job.progress}% - {job.message}")
    
    def _on_job_completion(self, job: Job):
        """Callback cuando se completa un trabajo"""
        logger.info(f"Job {job.job_id} completed successfully")
    
    def _on_job_error(self, job: Job):
        """Callback cuando falla un trabajo"""
        logger.error(f"Job {job.job_id} failed: {job.error_details}")
    
    def get_job(self, job_id: str) -> Optional[Job]:
        """Obtiene un trabajo por ID"""
        return self.jobs.get(job_id)
    
    def get_job_status(self, job_id: str) -> Optional[JobStatus]:
        """Obtiene el estado de un trabajo por ID"""
        job = self.get_job(job_id)
        return job.to_status() if job else None
    
    def get_dataset_jobs(self, dataset_id: str) -> List[Job]:
        """Obtiene todos los trabajos de un dataset"""
        return [job for job in self.jobs.values() if job.dataset_id == dataset_id]
    
    def cancel_job(self, job_id: str) -> bool:
        """Cancela un trabajo si está en cola"""
        job = self.get_job(job_id)
        if job and job.state == JobState.QUEUED:
            job.state = JobState.ERROR
            job.message = "Trabajo cancelado por el usuario"
            job.updated_at = datetime.now()
            return True
        return False
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del gestor de trabajos"""
        return {
            **self.stats,
            'active_workers': len(self.workers),
            'queue_size': self.job_queue.qsize(),
            'total_jobs_in_memory': len(self.jobs)
        }
    
    def cleanup_old_jobs(self, max_age_hours: int = 24):
        """Limpia trabajos antiguos de la memoria"""
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        old_job_ids = [
            job_id for job_id, job in self.jobs.items()
            if job.updated_at < cutoff_time and job.state in [JobState.DONE, JobState.ERROR]
        ]
        
        for job_id in old_job_ids:
            del self.jobs[job_id]
        
        if old_job_ids:
            logger.info(f"Cleaned up {len(old_job_ids)} old jobs")
    
    def get_jobs_by_state(self, state: JobState) -> List[Job]:
        """Obtiene trabajos por estado"""
        return [job for job in self.jobs.values() if job.state == state]
    
    def get_jobs_by_type(self, job_type: JobType) -> List[Job]:
        """Obtiene trabajos por tipo"""
        return [job for job in self.jobs.values() if job.job_type == job_type]


# Instancia global del gestor de trabajos
job_manager = JobManager()
