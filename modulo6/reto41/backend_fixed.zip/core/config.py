import os
from typing import List, Optional
from pydantic import BaseSettings, validator
from pathlib import Path


class Settings(BaseSettings):
    """Configuración de la aplicación cargada desde variables de entorno"""
    
    # Configuración del servidor
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG: bool = True
    
    # Límites de archivos
    MAX_UPLOAD_MB: int = 100
    MAX_FILE_SIZE: int = 104857600  # 100MB en bytes
    
    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173"
    ]
    
    # Caché y TTL
    ARTIFACT_TTL_DAYS: int = 30
    CACHE_TTL_HOURS: int = 24
    REDIS_URL: str = "redis://localhost:6379"
    
    # Funcionalidades
    ENABLE_PDF: bool = True
    ENABLE_WEBSOCKET: bool = True
    ENABLE_RATE_LIMIT: bool = True
    
    # Límites de rate
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_PER_HOUR: int = 1000
    
    # Configuración de EDA
    MAX_ROWS_FOR_FULL_ANALYSIS: int = 100000
    SAMPLE_SIZE_FOR_LARGE_DATASETS: int = 10000
    OUTLIER_THRESHOLD: float = 1.5
    CORRELATION_THRESHOLD: float = 0.5
    
    # Configuración de gráficos
    MAX_CHART_BINS: int = 50
    MAX_TIME_SERIES_POINTS: int = 1000
    CHART_HEIGHT: int = 400
    CHART_WIDTH: int = 600
    
    # Configuración de reportes
    REPORT_TEMPLATE_PATH: str = "templates/report.html"
    REPORT_LANGUAGES: List[str] = ["es", "en"]
    DEFAULT_LANGUAGE: str = "es"
    
    # Configuración de almacenamiento
    UPLOADS_DIR: str = "uploads"
    ARTIFACTS_DIR: str = "artifacts"
    TEMP_DIR: str = "temp"
    
    # Configuración de seguridad
    SECRET_KEY: str = "your-secret-key-here-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # Configuración de logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"
    
    @validator('CORS_ORIGINS', pre=True)
    def parse_cors_origins(cls, v):
        if isinstance(v, str):
            return [i.strip() for i in v.split(',')]
        return v
    
    @property
    def base_dir(self) -> Path:
        """Directorio base del proyecto"""
        return Path(__file__).parent.parent
    
    @property
    def uploads_dir(self) -> Path:
        """Directorio de uploads"""
        return self.base_dir / self.UPLOADS_DIR
    
    @property
    def artifacts_dir(self) -> Path:
        """Directorio de artefactos"""
        return self.base_dir / self.ARTIFACTS_DIR
    
    @property
    def temp_dir(self) -> Path:
        """Directorio temporal"""
        return self.base_dir / self.TEMP_DIR
    
    @property
    def templates_dir(self) -> Path:
        """Directorio de plantillas"""
        return self.base_dir / "templates"
    
    def create_directories(self):
        """Crea los directorios necesarios si no existen"""
        self.uploads_dir.mkdir(exist_ok=True)
        self.artifacts_dir.mkdir(exist_ok=True)
        self.temp_dir.mkdir(exist_ok=True)
        self.templates_dir.mkdir(exist_ok=True)
    
    class Config:
        env_file = ".env"
        case_sensitive = False


# Instancia global de configuración
settings = Settings()

# Crear directorios al importar
settings.create_directories()
