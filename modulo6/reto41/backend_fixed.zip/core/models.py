from typing import List, Dict, Any, Optional, Union
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, validator
import uuid


class JobState(str, Enum):
    """Estados posibles de un trabajo"""
    QUEUED = "queued"
    RUNNING = "running"
    DONE = "done"
    ERROR = "error"


class FileType(str, Enum):
    """Tipos de archivo soportados"""
    CSV = "csv"
    EXCEL = "excel"


class DataType(str, Enum):
    """Tipos de datos semánticos detectados"""
    NUMERIC = "numeric"
    CATEGORICAL = "categorical"
    DATETIME = "datetime"
    TEXT = "text"
    BOOLEAN = "boolean"
    CURRENCY = "currency"
    PERCENTAGE = "percentage"
    EMAIL = "email"
    PHONE = "phone"
    IDENTIFIER = "identifier"


class UploadRequest(BaseModel):
    """Solicitud de subida de archivo"""
    sheet: Optional[str] = Field(None, description="Nombre de la hoja para archivos Excel")


class UploadResponse(BaseModel):
    """Respuesta de subida de archivo"""
    dataset_id: str = Field(..., description="ID único del dataset")
    job_id: str = Field(..., description="ID del trabajo de procesamiento")
    filename: str = Field(..., description="Nombre del archivo subido")
    file_size: int = Field(..., description="Tamaño del archivo en bytes")
    message: str = Field(..., description="Mensaje de confirmación")


class JobStatus(BaseModel):
    """Estado de un trabajo"""
    job_id: str = Field(..., description="ID del trabajo")
    dataset_id: str = Field(..., description="ID del dataset")
    state: JobState = Field(..., description="Estado actual del trabajo")
    progress: int = Field(..., ge=0, le=100, description="Progreso del 0 al 100")
    message: str = Field(..., description="Mensaje descriptivo del estado")
    created_at: datetime = Field(..., description="Fecha de creación del trabajo")
    updated_at: datetime = Field(..., description="Última actualización del trabajo")
    estimated_completion: Optional[datetime] = Field(None, description="Estimación de finalización")
    error_details: Optional[str] = Field(None, description="Detalles del error si ocurrió")


class ColumnProfile(BaseModel):
    """Perfil de una columna"""
    name: str = Field(..., description="Nombre de la columna")
    data_type: DataType = Field(..., description="Tipo de datos detectado")
    null_count: int = Field(..., description="Cantidad de valores nulos")
    null_percentage: float = Field(..., description="Porcentaje de valores nulos")
    unique_count: int = Field(..., description="Cantidad de valores únicos")
    unique_percentage: float = Field(..., description="Porcentaje de valores únicos")
    
    # Estadísticas específicas por tipo
    numeric_stats: Optional[Dict[str, Any]] = Field(None, description="Estadísticas para datos numéricos")
    categorical_stats: Optional[Dict[str, Any]] = Field(None, description="Estadísticas para datos categóricos")
    datetime_stats: Optional[Dict[str, Any]] = Field(None, description="Estadísticas para datos de fecha/hora")
    
    # Detección de patrones
    patterns: Optional[List[str]] = Field(None, description="Patrones detectados en los datos")
    suggestions: Optional[List[str]] = Field(None, description="Sugerencias de limpieza")


class DatasetSummary(BaseModel):
    """Resumen del dataset"""
    dataset_id: str = Field(..., description="ID del dataset")
    filename: str = Field(..., description="Nombre del archivo")
    total_rows: int = Field(..., description="Total de filas")
    total_columns: int = Field(..., description="Total de columnas")
    file_size_mb: float = Field(..., description="Tamaño del archivo en MB")
    upload_date: datetime = Field(..., description="Fecha de subida")
    
    # Calidad de datos
    data_quality_score: float = Field(..., ge=0, le=100, description="Puntuación de calidad de datos")
    completeness_score: float = Field(..., ge=0, le=100, description="Puntuación de completitud")
    consistency_score: float = Field(..., ge=0, le=100, description="Puntuación de consistencia")
    
    # Información de muestreo
    sampling_applied: bool = Field(False, description="Si se aplicó muestreo")
    sampling_notice: Optional[str] = Field(None, description="Nota sobre el muestreo aplicado")
    original_row_count: Optional[int] = Field(None, description="Cantidad original de filas")
    
    # Resumen por tipos
    numeric_columns: int = Field(..., description="Cantidad de columnas numéricas")
    categorical_columns: int = Field(..., description="Cantidad de columnas categóricas")
    datetime_columns: int = Field(..., description="Cantidad de columnas de fecha/hora")
    text_columns: int = Field(..., description="Cantidad de columnas de texto")
    
    # Problemas detectados
    missing_data_columns: List[str] = Field(default_factory=list, description="Columnas con datos faltantes")
    duplicate_rows: int = Field(..., description="Cantidad de filas duplicadas")
    outlier_columns: List[str] = Field(default_factory=list, description="Columnas con outliers")


class ChartTrace(BaseModel):
    """Traza de gráfico Plotly"""
    chart_id: str = Field(..., description="ID único del gráfico")
    chart_type: str = Field(..., description="Tipo de gráfico")
    title: str = Field(..., description="Título del gráfico")
    description: str = Field(..., description="Descripción del gráfico")
    plotly_data: Dict[str, Any] = Field(..., description="Datos del gráfico en formato Plotly")
    plotly_layout: Dict[str, Any] = Field(..., description="Layout del gráfico en formato Plotly")
    columns_involved: List[str] = Field(..., description="Columnas utilizadas en el gráfico")
    insights: Optional[str] = Field(None, description="Insights extraídos del gráfico")


class Insight(BaseModel):
    """Insight generado por análisis automático"""
    insight_id: str = Field(..., description="ID único del insight")
    category: str = Field(..., description="Categoría del insight")
    title: str = Field(..., description="Título del insight")
    description: str = Field(..., description="Descripción detallada")
    severity: str = Field(..., description="Severidad: info, warning, error")
    confidence: float = Field(..., ge=0, le=1, description="Nivel de confianza del insight")
    columns_affected: List[str] = Field(..., description="Columnas afectadas")
    recommendations: List[str] = Field(..., description="Recomendaciones de acción")
    metrics: Dict[str, Any] = Field(..., description="Métricas relacionadas")


class DatasetProfile(BaseModel):
    """Perfil completo del dataset"""
    dataset_id: str = Field(..., description="ID del dataset")
    summary: DatasetSummary = Field(..., description="Resumen del dataset")
    columns: List[ColumnProfile] = Field(..., description="Perfiles de todas las columnas")
    
    # Análisis estadístico
    correlations: Dict[str, Dict[str, float]] = Field(..., description="Matriz de correlaciones")
    missing_patterns: Dict[str, Any] = Field(..., description="Patrones de datos faltantes")
    outlier_analysis: Dict[str, Any] = Field(..., description="Análisis de outliers")
    
    # Series de tiempo
    time_series_info: Optional[Dict[str, Any]] = Field(None, description="Información de series de tiempo")
    
    # Generado en
    generated_at: datetime = Field(..., description="Fecha de generación del perfil")


class ExportRequest(BaseModel):
    """Solicitud de exportación de datos limpios"""
    format: str = Field(..., description="Formato de exportación: csv, parquet")
    columns: Optional[List[str]] = Field(None, description="Columnas específicas a exportar")
    filters: Optional[Dict[str, Any]] = Field(None, description="Filtros a aplicar")


class ReportRequest(BaseModel):
    """Solicitud de generación de reporte"""
    language: str = Field("es", description="Idioma del reporte: es, en")
    sections: List[str] = Field(..., description="Secciones a incluir en el reporte")
    include_charts: bool = Field(True, description="Incluir gráficos en el reporte")
    include_pdf: bool = Field(True, description="Generar versión PDF")


class ReportResponse(BaseModel):
    """Respuesta de generación de reporte"""
    report_id: str = Field(..., description="ID único del reporte")
    html_path: str = Field(..., description="Ruta al reporte HTML")
    pdf_path: Optional[str] = Field(None, description="Ruta al reporte PDF si se generó")
    language: str = Field(..., description="Idioma del reporte")
    sections: List[str] = Field(..., description="Secciones incluidas")
    generated_at: datetime = Field(..., description="Fecha de generación")


class BundleResponse(BaseModel):
    """Respuesta del bundle completo del dataset"""
    dataset_id: str = Field(..., description="ID del dataset")
    summary: DatasetSummary = Field(..., description="Resumen del dataset")
    profile: DatasetProfile = Field(..., description="Perfil completo del dataset")
    charts: List[ChartTrace] = Field(..., description="Gráficos generados")
    insights: List[Insight] = Field(..., description="Insights generados")
    artifacts: Dict[str, str] = Field(..., description="Rutas a artefactos generados")
    sample_preview: List[Dict[str, Any]] = Field(..., description="Vista previa de los datos")
    
    # Metadatos
    generated_at: datetime = Field(..., description="Fecha de generación del bundle")
    processing_time_seconds: float = Field(..., description="Tiempo de procesamiento en segundos")


class ErrorResponse(BaseModel):
    """Respuesta de error estándar"""
    error: str = Field(..., description="Tipo de error")
    message: str = Field(..., description="Mensaje descriptivo del error")
    details: Optional[Dict[str, Any]] = Field(None, description="Detalles adicionales del error")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Timestamp del error")


class SuccessResponse(BaseModel):
    """Respuesta de éxito estándar"""
    message: str = Field(..., description="Mensaje de éxito")
    data: Optional[Dict[str, Any]] = Field(None, description="Datos de la respuesta")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Timestamp de la respuesta")


# Funciones de utilidad para generar IDs únicos
def generate_dataset_id() -> str:
    """Genera un ID único para un dataset"""
    return f"dataset_{uuid.uuid4().hex[:8]}"


def generate_job_id() -> str:
    """Genera un ID único para un trabajo"""
    return f"job_{uuid.uuid4().hex[:8]}"


def generate_report_id() -> str:
    """Genera un ID único para un reporte"""
    return f"report_{uuid.uuid4().hex[:8]}"
