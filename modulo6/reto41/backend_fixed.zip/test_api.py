#!/usr/bin/env python3
"""
Script de prueba para verificar la API de AnalizadorDatos v2
"""

import requests
import json
import time
from pathlib import Path

# Configuración
BASE_URL = "http://localhost:8000"
TEST_FILE_PATH = "test_data.csv"  # Crear un archivo de prueba simple

def create_test_data():
    """Crea datos de prueba"""
    test_data = """id,nombre,edad,ciudad,salario,fecha
1,Juan,25,Madrid,30000,2023-01-15
2,María,30,Barcelona,35000,2023-01-16
3,Carlos,28,Valencia,32000,2023-01-17
4,Ana,35,Sevilla,40000,2023-01-18
5,Luis,27,Bilbao,31000,2023-01-19
6,Sofia,32,Zaragoza,38000,2023-01-20
7,Pedro,29,Málaga,33000,2023-01-21
8,Laura,31,Granada,36000,2023-01-22
9,Diego,26,Alicante,29000,2023-01-23
10,Carmen,33,Oviedo,42000,2023-01-24"""
    
    with open(TEST_FILE_PATH, 'w', encoding='utf-8') as f:
        f.write(test_data)
    
    print(f"✅ Datos de prueba creados en {TEST_FILE_PATH}")

def test_health_check():
    """Prueba el endpoint de salud"""
    try:
        response = requests.get(f"{BASE_URL}/health")
        if response.status_code == 200:
            print("✅ Health check exitoso")
            print(f"   Status: {response.json()['status']}")
            return True
        else:
            print(f"❌ Health check falló: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error en health check: {e}")
        return False

def test_upload():
    """Prueba la subida de archivo"""
    try:
        with open(TEST_FILE_PATH, 'rb') as f:
            files = {'file': ('test_data.csv', f, 'text/csv')}
            response = requests.post(f"{BASE_URL}/upload", files=files)
        
        if response.status_code == 200:
            data = response.json()
            print("✅ Upload exitoso")
            print(f"   Dataset ID: {data['dataset_id']}")
            print(f"   Job ID: {data['job_id']}")
            return data['dataset_id'], data['job_id']
        else:
            print(f"❌ Upload falló: {response.status_code}")
            print(f"   Error: {response.text}")
            return None, None
    except Exception as e:
        print(f"❌ Error en upload: {e}")
        return None, None

def test_job_status(job_id):
    """Prueba el estado del trabajo"""
    try:
        response = requests.get(f"{BASE_URL}/status/{job_id}")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Status check exitoso")
            print(f"   Estado: {data['state']}")
            print(f"   Progreso: {data['progress']}%")
            print(f"   Mensaje: {data['message']}")
            return data['state']
        else:
            print(f"❌ Status check falló: {response.status_code}")
            return None
    except Exception as e:
        print(f"❌ Error en status check: {e}")
        return None

def wait_for_job_completion(job_id, max_wait=60):
    """Espera a que el trabajo se complete"""
    print(f"⏳ Esperando completación del trabajo... (máximo {max_wait}s)")
    
    start_time = time.time()
    while time.time() - start_time < max_wait:
        state = test_job_status(job_id)
        if state == 'done':
            print("✅ Trabajo completado exitosamente")
            return True
        elif state == 'error':
            print("❌ Trabajo falló")
            return False
        
        time.sleep(5)
    
    print("⏰ Tiempo de espera agotado")
    return False

def test_bundle(dataset_id):
    """Prueba el endpoint bundle"""
    try:
        response = requests.get(f"{BASE_URL}/bundle/{dataset_id}")
        if response.status_code == 200:
            data = response.json()
            print("✅ Bundle obtenido exitosamente")
            print(f"   Resumen: {data['summary']['total_rows']} filas, {data['summary']['total_columns']} columnas")
            print(f"   Gráficos: {len(data['charts'])} generados")
            print(f"   Insights: {len(data['insights'])} secciones")
            return True
        else:
            print(f"❌ Bundle falló: {response.status_code}")
            print(f"   Error: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Error en bundle: {e}")
        return False

def test_export_clean(dataset_id):
    """Prueba la exportación de datos limpios"""
    try:
        response = requests.get(f"{BASE_URL}/export-clean/{dataset_id}?format=csv")
        if response.status_code == 200:
            data = response.json()
            print("✅ Export limpio exitoso")
            print(f"   Formato: {data['format']}")
            print(f"   Filas: {data['rows']}")
            print(f"   Columnas: {data['columns']}")
            return True
        else:
            print(f"❌ Export limpio falló: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error en export limpio: {e}")
        return False

def test_report_download(dataset_id):
    """Prueba la descarga de reportes"""
    try:
        payload = {
            "dataset_id": dataset_id,
            "sections": ["data_quality", "distributions", "relationships"],
            "language": "es"
        }
        response = requests.post(f"{BASE_URL}/download-report", json=payload)
        if response.status_code == 200:
            data = response.json()
            print("✅ Descarga de reporte exitosa")
            print(f"   HTML: {data['html_url']}")
            if data.get('pdf_url'):
                print(f"   PDF: {data['pdf_url']}")
            return True
        else:
            print(f"❌ Descarga de reporte falló: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error en descarga de reporte: {e}")
        return False

def cleanup():
    """Limpia archivos de prueba"""
    try:
        if Path(TEST_FILE_PATH).exists():
            Path(TEST_FILE_PATH).unlink()
            print(f"✅ Archivo de prueba {TEST_FILE_PATH} eliminado")
    except Exception as e:
        print(f"⚠️ Error limpiando archivos: {e}")

def main():
    """Función principal de prueba"""
    print("🚀 Iniciando pruebas de AnalizadorDatos API v2")
    print("=" * 50)
    
    # Crear datos de prueba
    create_test_data()
    
    # Verificar salud de la API
    if not test_health_check():
        print("❌ API no está funcionando. Asegúrate de que esté ejecutándose en localhost:8000")
        cleanup()
        return
    
    # Probar upload
    dataset_id, job_id = test_upload()
    if not dataset_id or not job_id:
        print("❌ No se pudo crear el dataset")
        cleanup()
        return
    
    # Esperar completación del trabajo
    if not wait_for_job_completion(job_id):
        print("❌ El trabajo no se completó en el tiempo esperado")
        cleanup()
        return
    
    # Probar bundle
    test_bundle(dataset_id)
    
    # Probar export limpio
    test_export_clean(dataset_id)
    
    # Probar descarga de reporte
    test_report_download(dataset_id)
    
    print("\n" + "=" * 50)
    print("✅ Todas las pruebas completadas")
    
    # Limpiar
    cleanup()

if __name__ == "__main__":
    main()
